"use client"

import { useState, useCallback, useEffect } from "react"
import { Navbar } from "@/components/acoustitrack/navbar"
import { UploadPanel } from "@/components/acoustitrack/upload-panel"
import { WaveformVisualizer } from "@/components/acoustitrack/waveform-visualizer"
import { VADTimeline } from "@/components/acoustitrack/vad-timeline"
import { DOAChart } from "@/components/acoustitrack/doa-chart"
import { PolarDisplay } from "@/components/acoustitrack/polar-display"
import { MetricsBar } from "@/components/acoustitrack/metrics-bar"
import { PredictionPanel } from "@/components/acoustitrack/prediction-panel"
import { toast } from "sonner"

// Demo mock data - realistic voice activity and DOA patterns
const DEMO_DATA = {
  vad: [0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1],
  doa: [2, 4, 7, 10, 12, 14, 15, 14, 12, 10, 8, 6, 5, 7, 9, 12, 14, 15, 13, 10, 8, 6, 4, 5, 7, 9, 11, 12, 10, 8, 6, 5, 7, 9, 10, 8, 6, 5, 7, 8],
  snr_estimate: 18.5,
  duration_sec: 10.0,
}

interface AnalysisResult {
  vad: number[]
  doa: number[]
  snr_estimate: number
  duration_sec: number
  audioData?: number[][]
  sampleRate?: number
}

// Extract audio data from file using Web Audio API
async function extractAudioData(file: File): Promise<{ audioData: number[][], sampleRate: number, duration: number }> {
  const arrayBuffer = await file.arrayBuffer()
  const audioContext = new AudioContext()
  const audioBuffer = await audioContext.decodeAudioData(arrayBuffer)
  
  const sampleRate = audioBuffer.sampleRate
  const duration = audioBuffer.duration
  const numChannels = Math.min(audioBuffer.numberOfChannels, 4)
  
  // Extract channel data
  const audioData: number[][] = []
  for (let i = 0; i < 4; i++) {
    if (i < numChannels) {
      const channelData = audioBuffer.getChannelData(i)
      audioData.push(Array.from(channelData))
    } else {
      // Duplicate first channel if less than 4 channels
      const channelData = audioBuffer.getChannelData(0)
      audioData.push(Array.from(channelData))
    }
  }
  
  await audioContext.close()
  return { audioData, sampleRate, duration }
}

export default function AcoustiTrackDashboard() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [isApiConnected, setIsApiConnected] = useState(false)

  // Test API connection via our proxy
  const testConnection = useCallback(async (): Promise<boolean> => {
    console.log("[v0] Testing API connection...")
    try {
      const response = await fetch("/api/colab/health")
      console.log("[v0] Health response status:", response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Health data:", data)
        if (data.status === "ok") {
          console.log("[v0] API connected!")
          setIsApiConnected(true)
          return true
        }
      }
      console.log("[v0] API not connected")
      setIsApiConnected(false)
      return false
    } catch (error) {
      console.log("[v0] Connection error:", error)
      setIsApiConnected(false)
      return false
    }
  }, [])

  // Test API connection on mount and periodically
  useEffect(() => {
    testConnection()
    
    // Auto-test every 10 seconds until connected
    const interval = setInterval(() => {
      testConnection()
    }, 10000)
    
    return () => clearInterval(interval)
  }, [testConnection])

  const handleAnalyze = useCallback(async (file: File | null) => {
    if (!file) return

    setIsLoading(true)
    setIsProcessing(true)
    setResult(null)

    // Extract real audio data for visualization
    let audioData: number[][] | undefined
    let sampleRate = 16000
    let fileDuration = 10

    try {
      const extracted = await extractAudioData(file)
      audioData = extracted.audioData
      sampleRate = extracted.sampleRate
      fileDuration = extracted.duration
    } catch (err) {
      console.error("Could not extract audio data:", err)
    }

    try {
      // Send to API
      const formData = new FormData()
      formData.append("audio", file)

      console.log("[v0] Sending request to /api/colab/analyze...")
      const response = await fetch("/api/colab/analyze", {
        method: "POST",
        body: formData,
      })

      console.log("[v0] Response status:", response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Analysis successful!")
          
          // Debug: log the raw API response
          console.log("[v0] Raw API response:", JSON.stringify(data, null, 2))
          console.log("[v0] VAD prediction:", data.vad?.prediction)
          console.log("[v0] VAD confidence:", data.vad?.confidence)
          console.log("[v0] VAD timeline length:", data.vad?.timeline?.length)
          console.log("[v0] First 5 timeline entries:", data.vad?.timeline?.slice(0, 5))
          
          // Transform response to match our format
          const transformedResult: AnalysisResult = {
            vad: data.vad?.timeline?.map((f: { label: string }) => f.label === "voice" ? 1 : 0) || DEMO_DATA.vad,
            doa: data.doa?.trajectory?.map((d: { angle: number }) => d.angle) || DEMO_DATA.doa,
            snr_estimate: data.metrics?.snr || DEMO_DATA.snr_estimate,
            duration_sec: data.metadata?.duration || fileDuration,
            audioData: audioData,
            sampleRate: sampleRate,
          }
          
          console.log("[v0] Transformed VAD:", transformedResult.vad.slice(0, 10))
          
          setResult(transformedResult)
          setIsLoading(false)
          setIsProcessing(false)
          toast.success("Analyse terminee via HuggingFace!")
          return
        } else {
          // Response not ok
          const errorText = await response.text()
          console.log("[v0] API error response:", errorText.substring(0, 500))
          toast.error("Erreur API: " + errorText.substring(0, 100))
        }
      
      // Fallback to demo mode
      console.log("[v0] Falling back to demo mode")
      toast.info("Mode demonstration active")
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setResult(DEMO_DATA)
    } catch (error) {
      console.error("[v0] Analysis error:", error)
      toast.error("Erreur d'analyse - Mode demo active")
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setResult(DEMO_DATA)
    } finally {
      console.log("[v0] Analysis complete, resetting loading states")
      setIsLoading(false)
      setIsProcessing(false)
    }
  }, [])

  const handleRunDemo = useCallback(async () => {
    setIsProcessing(true)
    setIsLoading(true)
    setResult(null)

    // Simulate realistic processing delay
    await new Promise((resolve) => setTimeout(resolve, 2000))
    
    setResult(DEMO_DATA)
    setIsLoading(false)
    setIsProcessing(false)
    toast.success("Demonstration chargee")
  }, [])

  const hasResult = result !== null

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        isProcessing={isProcessing}
        isApiConnected={isApiConnected}
        onTestConnection={testConnection}
      />

      <main className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
        {/* Section 1: Chaine d'Acquisition et Specifications */}
        <UploadPanel
          onAnalyze={handleAnalyze}
          onRunDemo={handleRunDemo}
          isLoading={isLoading}
          hasAnalyzed={hasResult}
        />

        {/* Section 2: Prediction Results */}
        <PredictionPanel
          vadData={result?.vad || []}
          doaData={result?.doa || []}
          isVisible={hasResult}
        />

        {/* Section 3: Waveform Visualizer */}
        <WaveformVisualizer 
          isVisible={hasResult} 
          audioData={result?.audioData}
          duration={result?.duration_sec}
          sampleRate={result?.sampleRate}
        />

        {/* Section 4: VAD Timeline */}
        <VADTimeline
          vadData={result?.vad || []}
          isVisible={hasResult}
          durationSec={result?.duration_sec || 10}
          audioData={result?.audioData}
        />

        {/* Section 5: DoA Tracking - Two columns */}
        {hasResult && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-3">
              <DOAChart doaData={result?.doa || []} isVisible={hasResult} />
            </div>
            <div className="lg:col-span-2">
              <PolarDisplay doaData={result?.doa || []} isVisible={hasResult} />
            </div>
          </div>
        )}

        {/* Section 6: Metrics Bar */}
        <MetricsBar
          durationSec={result?.duration_sec || 0}
          snrEstimate={result?.snr_estimate || 0}
          vadData={result?.vad || []}
          doaData={result?.doa || []}
          isVisible={hasResult}
        />

        {/* Footer */}
        {hasResult && (
          <div className="text-center py-4 border-t border-border">
            <p className="text-xs text-muted-foreground">
              AcoustiTrack v1.0 - Systeme de Detection et Localisation Acoustique par CNN-1D
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Plateforme: Raspberry Pi 3B | Reseau: PS Eye 4 Microphones | Echantillonnage: 16 kHz
              {isApiConnected && <span className="text-[#22c55e]"> | API: Connectee</span>}
            </p>
          </div>
        )}
      </main>
    </div>
  )
}
