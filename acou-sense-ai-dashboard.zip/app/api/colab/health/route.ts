import { NextResponse } from "next/server"

// URL permanente Hugging Face Space
const HF_API_URL = "https://csprojectworkspace-acoustitrack-api.hf.space"

export async function GET() {
  console.log("[v0] Testing HF API connection to:", HF_API_URL)
  
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 30000) // 30s timeout
    
    const response = await fetch(`${HF_API_URL}/api/health`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
      },
      cache: "no-store",
      signal: controller.signal,
    })
    
    clearTimeout(timeoutId)
    
    console.log("[v0] HF API response status:", response.status)

    if (!response.ok) {
      const text = await response.text()
      console.log("[v0] HF API error response:", text.substring(0, 500))
      return NextResponse.json(
        { error: "Serveur HF non disponible", status: response.status, details: text.substring(0, 200) },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log("[v0] HF API success:", data)
    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Erreur connexion HF:", error)
    return NextResponse.json(
      { error: "Impossible de joindre le serveur HF", details: String(error) },
      { status: 503 }
    )
  }
}
