import { NextRequest, NextResponse } from "next/server"

// URL permanente Hugging Face Space
const HF_API_URL = "https://csprojectworkspace-acoustitrack-api.hf.space"

export const maxDuration = 60 // Allow up to 60 seconds

export async function POST(request: NextRequest) {
  console.log("[v0] Starting analysis request...")
  
  try {
    const formData = await request.formData()
    const audioFile = formData.get("audio")
    console.log("[v0] Audio file received:", audioFile ? "yes" : "no")
    
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 55000) // 55s timeout
    
    console.log("[v0] Sending to HF API...")
    const response = await fetch(`${HF_API_URL}/api/analyze`, {
      method: "POST",
      body: formData,
      signal: controller.signal,
    })
    
    clearTimeout(timeoutId)
    console.log("[v0] HF API response status:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.log("[v0] HF API error:", errorText.substring(0, 500))
      return NextResponse.json(
        { error: errorText || "Erreur analyse HF", details: errorText.substring(0, 200) },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log("[v0] HF API success, VAD prediction:", data.vad?.prediction)
    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Erreur analyse HF:", error)
    return NextResponse.json(
      { error: "Impossible de joindre le serveur HF", details: String(error) },
      { status: 503 }
    )
  }
}
