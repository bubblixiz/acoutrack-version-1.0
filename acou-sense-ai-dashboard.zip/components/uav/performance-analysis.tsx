"use client";

import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gauge, Clock, BarChart3, Zap } from "lucide-react";

interface PerformanceAnalysisProps {
  signalLoaded: boolean;
}

export function PerformanceAnalysis({ signalLoaded }: PerformanceAnalysisProps) {
  const errorCanvasRef = useRef<HTMLCanvasElement>(null);

  const metrics = {
    snr: 18.5,
    snapshots: 512,
    executionTimes: {
      bartlett: 12,
      capon: 45,
      music: 78
    }
  };

  // Draw localization error graph
  useEffect(() => {
    if (!signalLoaded || !errorCanvasRef.current) return;
    
    const canvas = errorCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const padding = { left: 50, right: 20, top: 20, bottom: 30 };
    const plotWidth = width - padding.left - padding.right;
    const plotHeight = height - padding.top - padding.bottom;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + (i / 5) * plotHeight;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
    }

    // Draw axes
    ctx.strokeStyle = "#64748B";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padding.left, height - padding.bottom);
    ctx.lineTo(width - padding.right, height - padding.bottom);
    ctx.moveTo(padding.left, padding.top);
    ctx.lineTo(padding.left, height - padding.bottom);
    ctx.stroke();

    // Simulated error data (error vs SNR)
    const algorithms = [
      { name: "Bartlett", color: "#F59E0B", baseError: 8 },
      { name: "Capon", color: "#3B82F6", baseError: 4 },
      { name: "MUSIC", color: "#14B8A6", baseError: 2 },
    ];

    for (const algo of algorithms) {
      ctx.beginPath();
      ctx.strokeStyle = algo.color;
      ctx.lineWidth = 2;

      for (let i = 0; i <= 20; i++) {
        const snr = i;
        const error = algo.baseError * Math.exp(-snr / 10) + 0.5;
        
        const x = padding.left + (snr / 20) * plotWidth;
        const y = height - padding.bottom - (error / 10) * plotHeight;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    }

    // Labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "9px monospace";
    
    // X-axis
    ctx.textAlign = "center";
    for (let snr = 0; snr <= 20; snr += 5) {
      const x = padding.left + (snr / 20) * plotWidth;
      ctx.fillText(`${snr}`, x, height - padding.bottom + 12);
    }
    ctx.fillText("SNR (dB)", width / 2, height - 5);

    // Y-axis
    ctx.textAlign = "right";
    for (let error = 0; error <= 10; error += 2) {
      const y = height - padding.bottom - (error / 10) * plotHeight;
      ctx.fillText(`${error}°`, padding.left - 5, y + 3);
    }

    // Y-axis label
    ctx.save();
    ctx.translate(12, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillText("Error (degrees)", 0, 0);
    ctx.restore();

    // Current SNR marker
    const currentX = padding.left + (metrics.snr / 20) * plotWidth;
    ctx.strokeStyle = "#EF4444";
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(currentX, padding.top);
    ctx.lineTo(currentX, height - padding.bottom);
    ctx.stroke();
    ctx.setLineDash([]);

  }, [signalLoaded]);

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-chart-2"></div>
          PERFORMANCE ANALYSIS
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!signalLoaded ? (
          <div className="h-[200px] flex items-center justify-center border border-dashed border-border rounded-lg">
            <p className="text-sm text-muted-foreground font-mono">Load signal to analyze performance</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Gauge className="h-4 w-4 text-chart-2" />
                  <span className="text-xs font-mono text-muted-foreground">SNR Level</span>
                </div>
                <p className="text-xl font-mono font-semibold text-chart-2">{metrics.snr} dB</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <BarChart3 className="h-4 w-4 text-chart-3" />
                  <span className="text-xs font-mono text-muted-foreground">Snapshots</span>
                </div>
                <p className="text-xl font-mono font-semibold text-chart-3">{metrics.snapshots}</p>
              </div>
            </div>

            {/* Localization Error Graph */}
            <div>
              <p className="text-xs font-mono text-muted-foreground mb-2">LOCALIZATION ERROR vs SNR</p>
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={errorCanvasRef} className="w-full h-[120px]" />
              </div>
            </div>

            {/* Execution Time Comparison */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs font-mono text-muted-foreground">EXECUTION TIME COMPARISON</span>
              </div>
              <div className="space-y-2">
                {Object.entries(metrics.executionTimes).map(([algo, time]) => {
                  const colors: Record<string, string> = {
                    bartlett: "bg-chart-4",
                    capon: "bg-chart-3",
                    music: "bg-primary"
                  };
                  const maxTime = Math.max(...Object.values(metrics.executionTimes));
                  return (
                    <div key={algo} className="flex items-center gap-3">
                      <span className="text-xs font-mono text-muted-foreground w-16 capitalize">{algo}</span>
                      <div className="flex-1 h-3 bg-secondary rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${colors[algo]} rounded-full`}
                          style={{ width: `${(time / maxTime) * 100}%` }}
                        />
                      </div>
                      <Badge variant="outline" className="font-mono text-[10px] w-14 justify-center">
                        {time} ms
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
