"use client";

import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Target } from "lucide-react";

interface SourceLocalizationProps {
  signalLoaded: boolean;
  estimatedAngle: number;
}

export function SourceLocalization({ signalLoaded, estimatedAngle }: SourceLocalizationProps) {
  const polarCanvasRef = useRef<HTMLCanvasElement>(null);
  const comparisonCanvasRef = useRef<HTMLCanvasElement>(null);
  const [activeAlgorithm, setActiveAlgorithm] = useState("music");

  // Draw polar DOA plot
  useEffect(() => {
    if (!signalLoaded || !polarCanvasRef.current) return;
    
    const canvas = polarCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 2 - 40;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw polar grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;

    // Concentric circles
    for (let r = 0.25; r <= 1; r += 0.25) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Radial lines (every 30 degrees)
    for (let angle = 0; angle < 360; angle += 30) {
      const rad = (angle * Math.PI) / 180;
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX + Math.cos(rad) * radius, centerY - Math.sin(rad) * radius);
      ctx.stroke();
    }

    // Angle labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    const labelAngles = [0, 30, 60, 90, 120, 150, 180, -150, -120, -90, -60, -30];
    for (const angle of labelAngles) {
      const rad = ((90 - angle) * Math.PI) / 180;
      const x = centerX + Math.cos(rad) * (radius + 20);
      const y = centerY - Math.sin(rad) * (radius + 20);
      ctx.fillText(`${angle}°`, x, y + 4);
    }

    // Draw DOA spectrum based on algorithm
    const getSpectrum = (algorithm: string) => {
      const spectrum: number[] = [];
      for (let angle = -180; angle <= 180; angle++) {
        let power = 0;
        const peakAngle = estimatedAngle;
        
        if (algorithm === "bartlett") {
          power = Math.exp(-Math.pow(angle - peakAngle, 2) / 800) * 0.9;
          power += Math.random() * 0.1;
        } else if (algorithm === "capon") {
          power = Math.exp(-Math.pow(angle - peakAngle, 2) / 400) * 0.95;
          power += Math.random() * 0.05;
        } else { // MUSIC
          power = Math.exp(-Math.pow(angle - peakAngle, 2) / 200);
          power += Math.random() * 0.03;
        }
        spectrum.push(Math.min(1, power));
      }
      return spectrum;
    };

    const spectrum = getSpectrum(activeAlgorithm);
    const colors: Record<string, string> = {
      bartlett: "#F59E0B",
      capon: "#3B82F6",
      music: "#14B8A6"
    };

    // Draw spectrum
    ctx.beginPath();
    ctx.strokeStyle = colors[activeAlgorithm];
    ctx.lineWidth = 2;

    for (let i = 0; i < spectrum.length; i++) {
      const angle = i - 180;
      const rad = ((90 - angle) * Math.PI) / 180;
      const r = spectrum[i] * radius;
      const x = centerX + Math.cos(rad) * r;
      const y = centerY - Math.sin(rad) * r;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    ctx.stroke();

    // Fill spectrum
    ctx.fillStyle = `${colors[activeAlgorithm]}20`;
    ctx.fill();

    // Draw estimated angle indicator
    const estRad = ((90 - estimatedAngle) * Math.PI) / 180;
    ctx.beginPath();
    ctx.strokeStyle = "#EF4444";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(centerX + Math.cos(estRad) * radius, centerY - Math.sin(estRad) * radius);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw arrow at estimated angle
    const arrowX = centerX + Math.cos(estRad) * (radius - 20);
    const arrowY = centerY - Math.sin(estRad) * (radius - 20);
    ctx.beginPath();
    ctx.fillStyle = "#EF4444";
    ctx.arc(arrowX, arrowY, 6, 0, Math.PI * 2);
    ctx.fill();

  }, [signalLoaded, activeAlgorithm, estimatedAngle]);

  // Draw comparison plot
  useEffect(() => {
    if (!signalLoaded || !comparisonCanvasRef.current) return;
    
    const canvas = comparisonCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const padding = 40;
    const plotWidth = width - padding * 2;
    const plotHeight = height - padding * 2;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 10; i++) {
      const y = padding + (i / 10) * plotHeight;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }

    // Draw axes
    ctx.strokeStyle = "#64748B";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.stroke();

    // Algorithm spectra
    const algorithms = [
      { name: "Bartlett", color: "#F59E0B", variance: 800 },
      { name: "Capon", color: "#3B82F6", variance: 400 },
      { name: "MUSIC", color: "#14B8A6", variance: 200 },
    ];

    for (const algo of algorithms) {
      ctx.beginPath();
      ctx.strokeStyle = algo.color;
      ctx.lineWidth = 2;

      for (let x = 0; x <= plotWidth; x++) {
        const angle = (x / plotWidth) * 360 - 180;
        let power = Math.exp(-Math.pow(angle - estimatedAngle, 2) / algo.variance);
        power += Math.random() * 0.03;
        
        const plotX = padding + x;
        const plotY = height - padding - power * plotHeight;
        
        if (x === 0) {
          ctx.moveTo(plotX, plotY);
        } else {
          ctx.lineTo(plotX, plotY);
        }
      }
      ctx.stroke();
    }

    // Labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    
    // X-axis labels
    for (let angle = -180; angle <= 180; angle += 60) {
      const x = padding + ((angle + 180) / 360) * plotWidth;
      ctx.fillText(`${angle}°`, x, height - padding + 15);
    }

    // Legend
    let legendY = padding + 10;
    for (const algo of algorithms) {
      ctx.fillStyle = algo.color;
      ctx.fillRect(width - padding - 80, legendY, 12, 12);
      ctx.fillStyle = "#94A3B8";
      ctx.textAlign = "left";
      ctx.fillText(algo.name, width - padding - 62, legendY + 10);
      legendY += 18;
    }

    // Vertical line at estimated angle
    const estX = padding + ((estimatedAngle + 180) / 360) * plotWidth;
    ctx.strokeStyle = "#EF4444";
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(estX, padding);
    ctx.lineTo(estX, height - padding);
    ctx.stroke();
    ctx.setLineDash([]);

  }, [signalLoaded, estimatedAngle]);

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-destructive"></div>
          SOURCE LOCALIZATION (DOA)
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!signalLoaded ? (
          <div className="h-[350px] flex items-center justify-center border border-dashed border-border rounded-lg">
            <p className="text-sm text-muted-foreground font-mono">Load signal to localize</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Algorithm Selection */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-muted-foreground">ALGORITHM:</span>
                <div className="flex gap-1">
                  <Badge 
                    variant={activeAlgorithm === "bartlett" ? "default" : "outline"}
                    className="font-mono text-xs cursor-pointer"
                    onClick={() => setActiveAlgorithm("bartlett")}
                  >
                    Bartlett
                  </Badge>
                  <Badge 
                    variant={activeAlgorithm === "capon" ? "default" : "outline"}
                    className="font-mono text-xs cursor-pointer"
                    onClick={() => setActiveAlgorithm("capon")}
                  >
                    Capon
                  </Badge>
                  <Badge 
                    variant={activeAlgorithm === "music" ? "default" : "outline"}
                    className="font-mono text-xs cursor-pointer"
                    onClick={() => setActiveAlgorithm("music")}
                  >
                    MUSIC
                  </Badge>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-destructive" />
                <span className="text-lg font-mono font-semibold text-destructive">
                  {estimatedAngle}°
                </span>
              </div>
            </div>

            {/* Polar Plot */}
            <div className="bg-background rounded-lg border border-border p-2">
              <canvas ref={polarCanvasRef} className="w-full h-[250px]" />
            </div>

            {/* Comparison Plot */}
            <div>
              <p className="text-xs font-mono text-muted-foreground mb-2">ALGORITHM COMPARISON</p>
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={comparisonCanvasRef} className="w-full h-[150px]" />
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
