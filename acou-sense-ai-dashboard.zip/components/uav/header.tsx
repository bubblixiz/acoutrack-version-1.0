"use client";

import { Badge } from "@/components/ui/badge";
import { Radar, Radio, Mic, Target } from "lucide-react";

export function Header() {
  return (
    <header className="border-b border-border bg-card px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded bg-primary/20">
              <Radar className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight text-foreground">
                UAV Acoustic Detection &amp; Localization
              </h1>
              <p className="text-xs text-muted-foreground font-mono">
                Acoustic Signal Processing Platform
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-green-500"></span>
            </span>
            <span className="text-xs text-muted-foreground font-mono">
              Acquisition Chain Connected
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-xs gap-1.5 border-primary/50 text-primary">
              <Mic className="h-3 w-3" />
              4-Microphone Array
            </Badge>
            <Badge variant="outline" className="font-mono text-xs gap-1.5 border-chart-3/50 text-chart-3">
              <Radio className="h-3 w-3" />
              Multichannel Signal
            </Badge>
            <Badge variant="outline" className="font-mono text-xs gap-1.5 border-chart-4/50 text-chart-4">
              <Target className="h-3 w-3" />
              DOA Localization
            </Badge>
          </div>
        </div>
      </div>
    </header>
  );
}
