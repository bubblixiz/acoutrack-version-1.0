"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Waves, Music } from "lucide-react";

interface AcousticAnalysisProps {
  signalLoaded: boolean;
}

export function AcousticAnalysis({ signalLoaded }: AcousticAnalysisProps) {
  const dominantFrequencies = [
    { freq: 150, amplitude: -12, label: "Fundamental" },
    { freq: 300, amplitude: -18, label: "2nd Harmonic" },
    { freq: 600, amplitude: -24, label: "4th Harmonic" },
    { freq: 1200, amplitude: -32, label: "8th Harmonic" },
  ];

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-chart-4"></div>
          ACOUSTIC SIGNATURE ANALYSIS
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!signalLoaded ? (
          <div className="h-[200px] flex items-center justify-center border border-dashed border-border rounded-lg">
            <p className="text-sm text-muted-foreground font-mono">Load signal to analyze</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Dominant Frequencies */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="h-4 w-4 text-primary" />
                <span className="text-xs font-mono text-muted-foreground">DOMINANT FREQUENCIES</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {dominantFrequencies.map((item) => (
                  <div key={item.freq} className="p-2 bg-secondary/50 rounded flex items-center justify-between">
                    <div>
                      <span className="text-sm font-mono font-semibold text-primary">{item.freq} Hz</span>
                      <p className="text-[10px] text-muted-foreground font-mono">{item.label}</p>
                    </div>
                    <Badge variant="outline" className="font-mono text-[10px]">
                      {item.amplitude} dB
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Energy Concentration Band */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Waves className="h-4 w-4 text-chart-3" />
                <span className="text-xs font-mono text-muted-foreground">ENERGY CONCENTRATION BAND</span>
              </div>
              <div className="p-3 bg-chart-3/10 border border-chart-3/30 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-mono font-semibold text-chart-3">100 Hz - 2 kHz</span>
                  <Badge className="bg-chart-3/20 text-chart-3 font-mono text-xs">87% Energy</Badge>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-chart-3 rounded-full" style={{ width: "87%" }}></div>
                </div>
              </div>
            </div>

            {/* Harmonic Components */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Music className="h-4 w-4 text-chart-4" />
                <span className="text-xs font-mono text-muted-foreground">HARMONIC COMPONENTS</span>
              </div>
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="font-mono text-[10px]">f₀ = 150 Hz</Badge>
                <Badge variant="outline" className="font-mono text-[10px]">2f₀</Badge>
                <Badge variant="outline" className="font-mono text-[10px]">4f₀</Badge>
                <Badge variant="outline" className="font-mono text-[10px]">8f₀</Badge>
                <Badge variant="outline" className="font-mono text-[10px]">12f₀</Badge>
              </div>
            </div>

            {/* Interpretation */}
            <div className="p-3 bg-primary/10 border border-primary/30 rounded-lg">
              <p className="text-xs font-mono text-primary leading-relaxed">
                <span className="font-semibold">INTERPRETATION:</span> Energy concentrated between 100 Hz and 2 kHz 
                characteristic of UAV acoustic signature. Harmonic structure consistent with multi-rotor propulsion system.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
