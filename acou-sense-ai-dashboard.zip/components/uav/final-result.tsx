"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, CheckCircle2, AlertTriangle } from "lucide-react";

interface FinalResultProps {
  signalLoaded: boolean;
  estimatedAngle: number;
}

export function FinalResult({ signalLoaded, estimatedAngle }: FinalResultProps) {
  const confidence = signalLoaded ? "High" : "N/A";
  const sourceType = "Mini-UAV";

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-chart-2"></div>
          DETECTION RESULT
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!signalLoaded ? (
          <div className="h-[180px] flex items-center justify-center border border-dashed border-border rounded-lg">
            <div className="text-center">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground font-mono">No signal loaded</p>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-chart-2/10 border-2 border-chart-2/50 rounded-lg">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-chart-2/20 flex items-center justify-center">
                  <CheckCircle2 className="h-7 w-7 text-chart-2" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-mono mb-1">SOURCE DETECTED</p>
                  <p className="text-2xl font-semibold font-mono text-chart-2">{sourceType}</p>
                </div>
              </div>
              <Badge className="bg-chart-2 text-chart-2-foreground font-mono">
                {confidence} Confidence
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="h-4 w-4 text-destructive" />
                  <span className="text-xs font-mono text-muted-foreground">LOCALIZATION ANGLE</span>
                </div>
                <p className="text-3xl font-mono font-bold text-destructive">{estimatedAngle}°</p>
              </div>
              <div className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="h-4 w-4 text-chart-2" />
                  <span className="text-xs font-mono text-muted-foreground">DETECTION STATUS</span>
                </div>
                <p className="text-lg font-mono font-semibold text-chart-2">Confirmed</p>
                <p className="text-xs font-mono text-muted-foreground">Multi-rotor signature matched</p>
              </div>
            </div>

            <div className="mt-4 p-3 bg-primary/10 border border-primary/30 rounded">
              <p className="text-xs font-mono text-primary">
                <span className="font-semibold">ANALYSIS COMPLETE:</span> Acoustic signature consistent with 
                quadrotor UAV. Direction of arrival estimated using MUSIC algorithm with 4-microphone array.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
