"use client";

import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, FileAudio, Check, Mic, Cpu, ArrowRight } from "lucide-react";

interface SignalMetadata {
  channels: number;
  samplingFrequency: number;
  duration: number;
  fileName: string;
}

interface AcquisitionPanelProps {
  onSignalLoaded: (metadata: SignalMetadata) => void;
  signalLoaded: boolean;
  metadata: SignalMetadata | null;
}

export function AcquisitionPanel({ onSignalLoaded, signalLoaded, metadata }: AcquisitionPanelProps) {
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith('.wav')) {
      // Simulate loading a 4-channel signal
      onSignalLoaded({
        channels: 4,
        samplingFrequency: 44100,
        duration: 5.2,
        fileName: file.name
      });
    }
  }, [onSignalLoaded]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith('.wav')) {
      onSignalLoaded({
        channels: 4,
        samplingFrequency: 44100,
        duration: 5.2,
        fileName: file.name
      });
    }
  }, [onSignalLoaded]);

  const handleLoadDemo = useCallback(() => {
    onSignalLoaded({
      channels: 4,
      samplingFrequency: 44100,
      duration: 5.2,
      fileName: "uav_recording_001.wav"
    });
  }, [onSignalLoaded]);

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-primary"></div>
          ACQUISITION CHAIN
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!signalLoaded ? (
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              isDragging ? "border-primary bg-primary/5" : "border-border"
            }`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            <Upload className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-2">
              Load Experimental Signal
            </p>
            <p className="text-xs text-muted-foreground/70 mb-4 font-mono">
              Upload multichannel .wav file only
            </p>
            <div className="flex gap-2 justify-center">
              <label>
                <input
                  type="file"
                  accept=".wav"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                <Button variant="outline" size="sm" className="font-mono text-xs" asChild>
                  <span>Browse Files</span>
                </Button>
              </label>
              <Button 
                variant="default" 
                size="sm" 
                className="font-mono text-xs"
                onClick={handleLoadDemo}
              >
                Load Demo Signal
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg border border-primary/30">
              <FileAudio className="h-5 w-5 text-primary" />
              <span className="text-sm font-mono text-primary flex-1">{metadata?.fileName}</span>
              <Check className="h-4 w-4 text-green-500" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground font-mono mb-1">Channels</p>
                <p className="text-lg font-semibold font-mono">{metadata?.channels} microphones</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground font-mono mb-1">Sampling Frequency</p>
                <p className="text-lg font-semibold font-mono">{metadata?.samplingFrequency} Hz</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground font-mono mb-1">Duration</p>
                <p className="text-lg font-semibold font-mono">{metadata?.duration.toFixed(2)} s</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground font-mono mb-1">Acquisition Device</p>
                <p className="text-sm font-semibold font-mono">PlayStation Eye Array</p>
              </div>
            </div>

            <div className="p-3 bg-secondary/30 rounded-lg">
              <p className="text-xs text-muted-foreground font-mono mb-2">Acquisition Platform</p>
              <Badge variant="outline" className="font-mono text-xs">Raspberry Pi 3B</Badge>
            </div>

            {/* Signal Flow Diagram */}
            <div className="p-4 bg-background/50 rounded-lg border border-border">
              <p className="text-xs text-muted-foreground font-mono mb-3 text-center">SIGNAL FLOW</p>
              <div className="flex items-center justify-center gap-2">
                <div className="flex flex-col items-center gap-1">
                  <div className="h-10 w-10 rounded bg-chart-3/20 flex items-center justify-center">
                    <Mic className="h-5 w-5 text-chart-3" />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">Microphones</span>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <div className="flex flex-col items-center gap-1">
                  <div className="h-10 w-10 rounded bg-chart-4/20 flex items-center justify-center">
                    <Cpu className="h-5 w-5 text-chart-4" />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">Acquisition</span>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <div className="flex flex-col items-center gap-1">
                  <div className="h-10 w-10 rounded bg-primary/20 flex items-center justify-center">
                    <FileAudio className="h-5 w-5 text-primary" />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">Processing</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
