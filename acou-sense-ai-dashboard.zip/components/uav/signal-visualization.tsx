"use client";

import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SignalVisualizationProps {
  signalLoaded: boolean;
}

export function SignalVisualization({ signalLoaded }: SignalVisualizationProps) {
  const timeCanvasRef = useRef<HTMLCanvasElement>(null);
  const fftCanvasRef = useRef<HTMLCanvasElement>(null);
  const spectrogramCanvasRef = useRef<HTMLCanvasElement>(null);
  const psdCanvasRef = useRef<HTMLCanvasElement>(null);
  const [activeTab, setActiveTab] = useState("time");

  // Generate simulated multichannel time domain data
  useEffect(() => {
    if (!signalLoaded || !timeCanvasRef.current) return;
    
    const canvas = timeCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const channelHeight = height / 4;
    const colors = ["#14B8A6", "#22C55E", "#3B82F6", "#F59E0B"];
    const channelLabels = ["Mic 1", "Mic 2", "Mic 3", "Mic 4"];

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;
    for (let i = 1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * channelHeight);
      ctx.lineTo(width, i * channelHeight);
      ctx.stroke();
    }

    // Draw each channel
    for (let ch = 0; ch < 4; ch++) {
      const yOffset = ch * channelHeight + channelHeight / 2;
      
      // Channel label
      ctx.fillStyle = colors[ch];
      ctx.font = "10px monospace";
      ctx.fillText(channelLabels[ch], 8, ch * channelHeight + 14);

      // Waveform
      ctx.beginPath();
      ctx.strokeStyle = colors[ch];
      ctx.lineWidth = 1;

      for (let x = 0; x < width; x++) {
        const t = x / width * 5.2;
        // Simulate UAV acoustic signature with harmonics
        const signal = 
          Math.sin(t * 150 * Math.PI * 2) * 0.3 +
          Math.sin(t * 300 * Math.PI * 2) * 0.2 +
          Math.sin(t * 600 * Math.PI * 2) * 0.15 +
          Math.sin(t * 1200 * Math.PI * 2) * 0.1 +
          (Math.random() - 0.5) * 0.1;
        
        const y = yOffset + signal * (channelHeight * 0.35);
        
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    }

    // Time axis labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "9px monospace";
    for (let i = 0; i <= 5; i++) {
      ctx.fillText(`${i}s`, (i / 5) * width - (i === 5 ? 15 : 0), height - 4);
    }
  }, [signalLoaded, activeTab]);

  // FFT visualization
  useEffect(() => {
    if (!signalLoaded || !fftCanvasRef.current || activeTab !== "fft") return;
    
    const canvas = fftCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;
    for (let i = 1; i < 10; i++) {
      ctx.beginPath();
      ctx.moveTo(0, (i / 10) * height);
      ctx.lineTo(width, (i / 10) * height);
      ctx.stroke();
    }

    // FFT spectrum with peaks at UAV characteristic frequencies
    const peakFrequencies = [150, 300, 600, 1200, 1800];
    
    ctx.beginPath();
    ctx.strokeStyle = "#14B8A6";
    ctx.lineWidth = 1.5;
    ctx.fillStyle = "rgba(20, 184, 166, 0.2)";

    const points: [number, number][] = [];
    for (let x = 0; x < width; x++) {
      const freq = (x / width) * 4000;
      let magnitude = 0;
      
      for (const peak of peakFrequencies) {
        magnitude += Math.exp(-Math.pow(freq - peak, 2) / 5000) * (0.8 - peak / 3000);
      }
      magnitude += Math.random() * 0.05;
      
      const y = height - magnitude * height * 0.8 - 20;
      points.push([x, y]);
      
      if (x === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();

    // Fill under curve
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fill();

    // Frequency labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "9px monospace";
    for (let i = 0; i <= 4; i++) {
      ctx.fillText(`${i}kHz`, (i / 4) * width - (i === 4 ? 25 : 0), height - 4);
    }

    // Y-axis label
    ctx.save();
    ctx.translate(12, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Magnitude (dB)", 0, 0);
    ctx.restore();
  }, [signalLoaded, activeTab]);

  // Spectrogram visualization
  useEffect(() => {
    if (!signalLoaded || !spectrogramCanvasRef.current || activeTab !== "spectrogram") return;
    
    const canvas = spectrogramCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Generate spectrogram data
    const peakFrequencies = [150, 300, 600, 1200, 1800];
    
    for (let x = 0; x < width; x += 2) {
      for (let y = 0; y < height - 20; y += 2) {
        const freq = ((height - 20 - y) / (height - 20)) * 4000;
        let intensity = 0;
        
        for (const peak of peakFrequencies) {
          intensity += Math.exp(-Math.pow(freq - peak, 2) / 3000) * 0.7;
        }
        intensity += Math.random() * 0.1;
        intensity = Math.min(1, intensity);

        // Color mapping (dark blue to cyan to yellow)
        const r = Math.floor(intensity * 255 * intensity);
        const g = Math.floor(intensity * 200);
        const b = Math.floor((1 - intensity * 0.5) * 150 + 50);
        
        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        ctx.fillRect(x, y, 2, 2);
      }
    }

    // Labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "9px monospace";
    ctx.fillText("0s", 4, height - 4);
    ctx.fillText("5.2s", width - 25, height - 4);
    
    ctx.save();
    ctx.translate(12, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Frequency (Hz)", 0, 0);
    ctx.restore();
  }, [signalLoaded, activeTab]);

  // PSD visualization
  useEffect(() => {
    if (!signalLoaded || !psdCanvasRef.current || activeTab !== "psd") return;
    
    const canvas = psdCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.5;
    for (let i = 1; i < 10; i++) {
      ctx.beginPath();
      ctx.moveTo(0, (i / 10) * height);
      ctx.lineTo(width, (i / 10) * height);
      ctx.stroke();
    }

    // PSD using Welch method (simulated)
    const peakFrequencies = [150, 300, 600, 1200, 1800];
    
    ctx.beginPath();
    ctx.strokeStyle = "#22C55E";
    ctx.lineWidth = 2;

    for (let x = 0; x < width; x++) {
      const freq = (x / width) * 4000;
      let psd = -60;
      
      for (const peak of peakFrequencies) {
        psd += Math.exp(-Math.pow(freq - peak, 2) / 4000) * 40;
      }
      psd += (Math.random() - 0.5) * 3;
      
      const y = height - ((psd + 60) / 60) * (height - 40) - 20;
      
      if (x === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();

    // Labels
    ctx.fillStyle = "#94A3B8";
    ctx.font = "9px monospace";
    for (let i = 0; i <= 4; i++) {
      ctx.fillText(`${i}kHz`, (i / 4) * width - (i === 4 ? 25 : 0), height - 4);
    }
    
    ctx.fillText("-60 dB/Hz", 4, height - 30);
    ctx.fillText("0 dB/Hz", 4, 15);
  }, [signalLoaded, activeTab]);

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-chart-3"></div>
          SIGNAL VISUALIZATION
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!signalLoaded ? (
          <div className="h-[300px] flex items-center justify-center border border-dashed border-border rounded-lg">
            <p className="text-sm text-muted-foreground font-mono">Load signal to visualize</p>
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-4">
              <TabsTrigger value="time" className="font-mono text-xs">Time Domain</TabsTrigger>
              <TabsTrigger value="fft" className="font-mono text-xs">FFT Spectrum</TabsTrigger>
              <TabsTrigger value="spectrogram" className="font-mono text-xs">Spectrogram</TabsTrigger>
              <TabsTrigger value="psd" className="font-mono text-xs">PSD (Welch)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="time" className="mt-0">
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={timeCanvasRef} className="w-full h-[280px]" />
              </div>
            </TabsContent>
            
            <TabsContent value="fft" className="mt-0">
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={fftCanvasRef} className="w-full h-[280px]" />
              </div>
            </TabsContent>
            
            <TabsContent value="spectrogram" className="mt-0">
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={spectrogramCanvasRef} className="w-full h-[280px]" />
              </div>
            </TabsContent>
            
            <TabsContent value="psd" className="mt-0">
              <div className="bg-background rounded-lg border border-border p-2">
                <canvas ref={psdCanvasRef} className="w-full h-[280px]" />
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}
