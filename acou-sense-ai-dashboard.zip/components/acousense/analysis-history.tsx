"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { History, Mic, MicOff, Volume2 } from "lucide-react"
import type { AnalysisResult } from "./result-panel"
import { cn } from "@/lib/utils"

interface AnalysisHistoryProps {
  history: (AnalysisResult & { filename: string })[]
}

export function AnalysisHistory({ history }: AnalysisHistoryProps) {
  const getIcon = (prediction: string) => {
    if (prediction === "Voice") return <Mic className="w-3.5 h-3.5" />
    if (prediction === "Silent") return <MicOff className="w-3.5 h-3.5" />
    return <Volume2 className="w-3.5 h-3.5" />
  }

  const getColor = (prediction: string) => {
    if (prediction === "Voice") return "#22C55E"
    if (prediction === "Silent") return "#6B7280"
    return "#F59E0B"
  }

  return (
    <Card className="bg-card border-border/50 h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <History className="w-5 h-5 text-primary" />
          Analysis History
        </CardTitle>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <History className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No analysis history yet</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {history.map((item, i) => (
                <div 
                  key={i}
                  className="bg-background/50 border border-border/30 rounded-lg p-3 animate-in fade-in slide-in-from-right-2"
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  {/* Mini waveform preview */}
                  <div className="flex items-center gap-1 h-6 mb-2">
                    {Array(12).fill(0).map((_, j) => (
                      <div
                        key={j}
                        className="w-1 rounded-full"
                        style={{
                          height: `${Math.random() * 80 + 20}%`,
                          backgroundColor: getColor(item.prediction),
                          opacity: 0.6
                        }}
                      />
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline"
                        className={cn(
                          "text-xs gap-1",
                          item.prediction === "Voice" && "bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/30",
                          item.prediction === "Silent" && "bg-muted text-muted-foreground border-border",
                          item.prediction === "Noise" && "bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/30"
                        )}
                      >
                        {getIcon(item.prediction)}
                        {item.prediction}
                      </Badge>
                      <span className="text-xs text-muted-foreground font-mono">
                        {item.confidence.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                    <span className="truncate max-w-[120px]">{item.filename}</span>
                    <span>{item.timestamp.toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}
