"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import { Upload, Mic, MicOff, Check, FileAudio } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

interface AudioFile {
  name: string
  duration: number
  size: number
  file: File
}

interface AudioInputProps {
  onAudioLoaded: (audio: AudioFile | null) => void
  onRecordingData: (data: number[]) => void
  isRecording: boolean
  setIsRecording: (value: boolean) => void
}

export function AudioInput({ onAudioLoaded, onRecordingData, isRecording, setIsRecording }: AudioInputProps) {
  const [uploadedFile, setUploadedFile] = useState<AudioFile | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [recordingBars, setRecordingBars] = useState<number[]>(Array(20).fill(10))
  const fileInputRef = useRef<HTMLInputElement>(null)
  const animationRef = useRef<number>()

  useEffect(() => {
    if (isRecording) {
      const animate = () => {
        const newBars = Array(20).fill(0).map(() => Math.random() * 80 + 20)
        setRecordingBars(newBars)
        onRecordingData(newBars)
        animationRef.current = requestAnimationFrame(animate)
      }
      animate()
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
      setRecordingBars(Array(20).fill(10))
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isRecording, onRecordingData])

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const file = e.dataTransfer.files[0]
    if (file && file.type.startsWith('audio/')) {
      await processFile(file)
    }
  }, [])

  const processFile = async (file: File) => {
    const duration = await getAudioDuration(file)
    const audioFile: AudioFile = {
      name: file.name,
      duration,
      size: file.size,
      file
    }
    setUploadedFile(audioFile)
    onAudioLoaded(audioFile)
  }

  const getAudioDuration = (file: File): Promise<number> => {
    return new Promise((resolve) => {
      const audio = new Audio()
      audio.src = URL.createObjectURL(file)
      audio.onloadedmetadata = () => {
        resolve(audio.duration)
        URL.revokeObjectURL(audio.src)
      }
    })
  }

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return (
    <Card className="bg-card border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <FileAudio className="w-5 h-5 text-primary" />
          Audio Input
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-background/50">
            <TabsTrigger value="upload" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Upload Audio
            </TabsTrigger>
            <TabsTrigger value="record" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Record Audio
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="mt-4">
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={cn(
                "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300",
                isDragging 
                  ? "border-primary bg-primary/10" 
                  : "border-border hover:border-primary/50 hover:bg-card/50"
              )}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".wav,audio/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) processFile(file)
                }}
              />
              
              {uploadedFile ? (
                <div className="space-y-3 animate-in fade-in duration-300">
                  <div className="w-16 h-16 mx-auto bg-[#22C55E]/20 rounded-full flex items-center justify-center">
                    <Check className="w-8 h-8 text-[#22C55E]" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{uploadedFile.name}</p>
                    <div className="flex items-center justify-center gap-4 mt-2 text-sm text-muted-foreground">
                      <span>{formatDuration(uploadedFile.duration)}</span>
                      <span>•</span>
                      <span>{formatSize(uploadedFile.size)}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                    <Upload className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Drop your audio file or browse</p>
                    <p className="text-sm text-muted-foreground mt-1">Supports .wav files</p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="record" className="mt-4">
            <div className="flex flex-col items-center gap-6 py-4">
              <button
                onClick={() => setIsRecording(!isRecording)}
                className={cn(
                  "relative w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300",
                  isRecording 
                    ? "bg-[#EF4444] shadow-[0_0_40px_rgba(239,68,68,0.5)]" 
                    : "bg-muted hover:bg-muted/80"
                )}
              >
                {isRecording && (
                  <div className="absolute inset-0 rounded-full bg-[#EF4444] animate-ping opacity-30" />
                )}
                {isRecording ? (
                  <MicOff className="w-10 h-10 text-white relative z-10" />
                ) : (
                  <Mic className="w-10 h-10 text-muted-foreground" />
                )}
              </button>

              {isRecording && (
                <div className="flex items-end justify-center gap-1 h-16 animate-in fade-in duration-300">
                  {recordingBars.map((height, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-[#EF4444] rounded-full transition-all duration-75"
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  variant={isRecording ? "destructive" : "default"}
                  onClick={() => setIsRecording(!isRecording)}
                  className={cn(
                    !isRecording && "bg-primary hover:bg-primary/90"
                  )}
                >
                  {isRecording ? "Stop Recording" : "Start Recording"}
                </Button>
                {isRecording && (
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setIsRecording(false)
                      onAudioLoaded({ name: "Recording", duration: 3.2, size: 51200, file: new File([], "recording.wav") })
                    }}
                    className="animate-in fade-in duration-300"
                  >
                    Analyze Recording
                  </Button>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
