"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, Mic, MicOff, Volume2 } from "lucide-react"
import { cn } from "@/lib/utils"

export interface AnalysisResult {
  prediction: "Voice" | "Silent" | "Noise"
  confidence: number
  channel: number
  processingTime: number
  probabilities: { label: string; value: number }[]
  timestamp: Date
}

interface ResultPanelProps {
  result: AnalysisResult | null
  isVisible: boolean
}

export function ResultPanel({ result, isVisible }: ResultPanelProps) {
  if (!isVisible || !result) return null

  const isVoice = result.prediction === "Voice"
  const isSilent = result.prediction === "Silent"
  const isLowConfidence = result.confidence < 80

  const getIcon = () => {
    if (isVoice) return <Mic className="w-8 h-8" />
    if (isSilent) return <MicOff className="w-8 h-8" />
    return <Volume2 className="w-8 h-8" />
  }

  const getColor = () => {
    if (isVoice) return "#22C55E"
    if (isSilent) return "#6B7280"
    return "#F59E0B"
  }

  return (
    <Card 
      className={cn(
        "bg-card border-border/50 animate-in fade-in slide-in-from-bottom-4 duration-500",
        isVoice && "border-[#22C55E]/30 shadow-[0_0_30px_rgba(34,197,94,0.1)]"
      )}
    >
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <span className="w-5 h-5 rounded-full flex items-center justify-center" style={{ backgroundColor: getColor() }}>
            <span className="w-2 h-2 rounded-full bg-white" />
          </span>
          Detection Result
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Result */}
        <div className="text-center py-6">
          <div 
            className={cn(
              "w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 transition-all",
              isVoice && "bg-[#22C55E]/20 text-[#22C55E] animate-pulse",
              isSilent && "bg-muted text-muted-foreground",
              !isVoice && !isSilent && "bg-[#F59E0B]/20 text-[#F59E0B]"
            )}
          >
            {getIcon()}
          </div>
          
          <Badge 
            className={cn(
              "text-2xl font-bold px-6 py-2 mb-4",
              isVoice && "bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/30",
              isSilent && "bg-muted text-muted-foreground border-border",
              !isVoice && !isSilent && "bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/30"
            )}
            variant="outline"
          >
            {result.prediction === "Voice" ? "VOICE DETECTED" : result.prediction === "Silent" ? "SILENT DETECTED" : "NOISE DETECTED"}
          </Badge>

          {isLowConfidence && (
            <div className="flex items-center justify-center gap-2 text-[#F59E0B] text-sm mt-2 animate-in fade-in">
              <AlertTriangle className="w-4 h-4" />
              Low Confidence — Possible Silence
            </div>
          )}
        </div>

        {/* Confidence Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Confidence</span>
            <span className="font-mono font-semibold" style={{ color: getColor() }}>
              {result.confidence.toFixed(1)}%
            </span>
          </div>
          <Progress 
            value={result.confidence} 
            className="h-3 bg-muted"
            style={{ 
              // @ts-expect-error CSS custom property
              '--progress-color': getColor()
            }}
          />
        </div>

        {/* Metadata */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="bg-background/50 rounded-lg p-3">
            <p className="text-muted-foreground">Channel</p>
            <p className="font-mono font-semibold text-foreground">Canal {result.channel}</p>
          </div>
          <div className="bg-background/50 rounded-lg p-3">
            <p className="text-muted-foreground">Processing Time</p>
            <p className="font-mono font-semibold text-foreground">{result.processingTime} ms</p>
          </div>
        </div>

        {/* Probability Breakdown */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground">Probability Breakdown</h4>
          {result.probabilities.map((prob, i) => (
            <div key={i} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-foreground">{prob.label}</span>
                <span className="font-mono text-muted-foreground">{prob.value}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{ 
                    width: `${prob.value}%`,
                    backgroundColor: i === 0 ? getColor() : '#334155'
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
