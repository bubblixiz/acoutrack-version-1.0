"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Zap, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface AnalyzeButtonProps {
  onAnalyze: () => void
  disabled: boolean
  isAnalyzing: boolean
}

const processingSteps = [
  "Extracting acoustic features…",
  "Preparing CNN input…",
  "Running inference…",
  "Computing probabilities…",
]

export function AnalyzeButton({ onAnalyze, disabled, isAnalyzing }: AnalyzeButtonProps) {
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    if (isAnalyzing) {
      setCurrentStep(0)
      const interval = setInterval(() => {
        setCurrentStep(prev => (prev + 1) % processingSteps.length)
      }, 800)
      return () => clearInterval(interval)
    }
  }, [isAnalyzing])

  return (
    <div className="flex flex-col items-center gap-4">
      <Button
        size="lg"
        onClick={onAnalyze}
        disabled={disabled || isAnalyzing}
        className={cn(
          "px-8 py-6 text-lg font-semibold transition-all duration-300",
          "bg-primary hover:bg-primary/90 text-primary-foreground",
          "shadow-[0_0_20px_rgba(20,184,166,0.3)]",
          "hover:shadow-[0_0_30px_rgba(20,184,166,0.5)]",
          isAnalyzing && "animate-pulse"
        )}
      >
        {isAnalyzing ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <Zap className="w-5 h-5 mr-2" />
            Analyze Signal
          </>
        )}
      </Button>

      {isAnalyzing && (
        <div className="flex flex-col items-center gap-2 animate-in fade-in duration-300">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
          <p className="text-sm text-muted-foreground font-mono animate-pulse">
            {processingSteps[currentStep]}
          </p>
        </div>
      )}
    </div>
  )
}
