"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Radio } from "lucide-react"

interface SignalVisualizationProps {
  hasAudio: boolean
  isAnalyzing: boolean
  recordingData?: number[]
}

export function SignalVisualization({ hasAudio, isAnalyzing, recordingData }: SignalVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()
  const [scanPosition, setScanPosition] = useState(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const draw = () => {
      const width = canvas.width
      const height = canvas.height

      // Clear canvas
      ctx.fillStyle = '#0F172A'
      ctx.fillRect(0, 0, width, height)

      // Draw grid
      ctx.strokeStyle = '#1E293B'
      ctx.lineWidth = 1

      // Vertical grid lines
      for (let x = 0; x < width; x += 40) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, height)
        ctx.stroke()
      }

      // Horizontal grid lines
      for (let y = 0; y < height; y += 20) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(width, y)
        ctx.stroke()
      }

      // Draw waveform
      if (hasAudio || recordingData) {
        const bars = recordingData || Array(60).fill(0).map(() => Math.random() * 0.8 + 0.2)
        const barWidth = width / bars.length
        
        ctx.fillStyle = '#14B8A6'
        
        bars.forEach((value, i) => {
          const barHeight = value * height * 0.4
          const x = i * barWidth
          const y = (height - barHeight) / 2
          
          // Create gradient for each bar
          const gradient = ctx.createLinearGradient(x, y, x, y + barHeight)
          gradient.addColorStop(0, '#14B8A6')
          gradient.addColorStop(0.5, '#14B8A6')
          gradient.addColorStop(1, '#0D9488')
          
          ctx.fillStyle = gradient
          ctx.fillRect(x + 2, y, barWidth - 4, barHeight)
        })

        // Mirror effect
        ctx.globalAlpha = 0.3
        bars.forEach((value, i) => {
          const barHeight = value * height * 0.2
          const x = i * barWidth
          const y = height / 2 + (height * 0.2)
          
          ctx.fillStyle = '#14B8A6'
          ctx.fillRect(x + 2, y, barWidth - 4, barHeight)
        })
        ctx.globalAlpha = 1
      } else {
        // Draw flat line when no audio
        ctx.strokeStyle = '#334155'
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(0, height / 2)
        ctx.lineTo(width, height / 2)
        ctx.stroke()
      }

      // Draw scanning line when analyzing
      if (isAnalyzing) {
        const scanX = (scanPosition % 100) * width / 100
        
        const gradient = ctx.createLinearGradient(scanX - 60, 0, scanX, 0)
        gradient.addColorStop(0, 'rgba(20, 184, 166, 0)')
        gradient.addColorStop(1, 'rgba(20, 184, 166, 0.8)')
        
        ctx.fillStyle = gradient
        ctx.fillRect(scanX - 60, 0, 60, height)
        
        ctx.strokeStyle = '#14B8A6'
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(scanX, 0)
        ctx.lineTo(scanX, height)
        ctx.stroke()

        setScanPosition(prev => prev + 2)
      }

      animationRef.current = requestAnimationFrame(draw)
    }

    draw()

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [hasAudio, isAnalyzing, recordingData, scanPosition])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect()
      canvas.width = rect.width * 2
      canvas.height = rect.height * 2
    }

    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)
    return () => window.removeEventListener('resize', resizeCanvas)
  }, [])

  return (
    <Card className="bg-card border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Radio className="w-5 h-5 text-primary" />
          Signal Visualization
          {isAnalyzing && (
            <span className="ml-auto text-xs font-normal text-primary animate-pulse">
              Analyzing...
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative rounded-xl overflow-hidden bg-[#0F172A] border border-border/30">
          <canvas
            ref={canvasRef}
            className="w-full h-48"
            style={{ imageRendering: 'pixelated' }}
          />
          {!hasAudio && !recordingData && (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-muted-foreground text-sm">
                Load audio to view signal
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
