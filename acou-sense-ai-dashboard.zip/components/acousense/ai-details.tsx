"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, Cpu, Layers, Signal, Clock, Tag } from "lucide-react"
import { cn } from "@/lib/utils"

interface AIDetailsProps {
  timestamp?: Date
}

export function AIDetails({ timestamp }: AIDetailsProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const details = [
    { icon: Cpu, label: "Model Type", value: "CNN 1D" },
    { icon: Layers, label: "Feature Length", value: "1024" },
    { icon: Signal, label: "Input Type", value: "Acoustic Signal" },
    { icon: Layers, label: "Sampling Mode", value: "4 Channels" },
    { icon: Clock, label: "Prediction Time", value: timestamp?.toLocaleTimeString() || "—" },
    { icon: Tag, label: "Model Version", value: "v1.0" },
  ]

  return (
    <Card className="bg-card border-border/50">
      <CardHeader 
        className="cursor-pointer select-none"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <CardTitle className="flex items-center justify-between text-foreground">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-primary" />
            AI Model Details
          </div>
          <ChevronDown 
            className={cn(
              "w-5 h-5 text-muted-foreground transition-transform duration-300",
              isExpanded && "rotate-180"
            )} 
          />
        </CardTitle>
      </CardHeader>
      
      <div 
        className={cn(
          "grid transition-all duration-300",
          isExpanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
        )}
      >
        <div className="overflow-hidden">
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {details.map((detail, i) => (
                <div 
                  key={i}
                  className="bg-background/50 border border-border/30 rounded-lg p-3 space-y-1"
                >
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <detail.icon className="w-3.5 h-3.5" />
                    <span className="text-xs">{detail.label}</span>
                  </div>
                  <p className="font-mono text-sm font-semibold text-foreground">
                    {detail.value}
                  </p>
                </div>
              ))}
            </div>
            
            <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <p className="text-xs text-muted-foreground font-mono">
                CNN architecture: Conv1D → BatchNorm → ReLU → MaxPool → Dense → Softmax
              </p>
            </div>
          </CardContent>
        </div>
      </div>
    </Card>
  )
}
