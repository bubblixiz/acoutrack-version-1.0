"use client"

import { useCallback, useState } from "react"
import { Upload, Check, Loader2, Play, FileAudio, Mic, HardDrive, Radio, Waves, CircuitBoard, Server } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface UploadPanelProps {
  onAnalyze: (file: File | null) => void
  onRunDemo: () => void
  isLoading: boolean
  hasAnalyzed: boolean
}

export function UploadPanel({ onAnalyze, onRunDemo, isLoading, hasAnalyzed }: UploadPanelProps) {
  const [file, setFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [loadingStep, setLoadingStep] = useState(0)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile && droppedFile.name.endsWith(".wav")) {
      setFile(droppedFile)
    }
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile && selectedFile.name.endsWith(".wav")) {
      setFile(selectedFile)
    }
  }, [])

  const handleAnalyzeClick = () => {
    setLoadingStep(0)
    const interval = setInterval(() => {
      setLoadingStep(prev => {
        if (prev >= 4) {
          clearInterval(interval)
          return prev
        }
        return prev + 1
      })
    }, 600)
    onAnalyze(file)
  }

  const loadingSteps = [
    "Chargement du signal audio...",
    "Preprocessing du signal...",
    "Inference CRNN (VAD)...",
    "Inference DOA (Localisation)...",
    "Finalisation des resultats..."
  ]

  return (
    <div className="space-y-4">
      {/* Main Section: Chaine d'Acquisition */}
      <Card className="p-6 bg-card border-border">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Radio className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">
              Chaine d&apos;Acquisition
            </h2>
            <p className="text-sm text-muted-foreground">
              Importation et traitement du signal acoustique multicanal
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
              <Waves className="h-3 w-3 mr-1" />
              4 Canaux
            </Badge>
            <Badge variant="outline" className="bg-[#f97316]/10 text-[#f97316] border-[#f97316]/30">
              16 kHz
            </Badge>
          </div>
        </div>

        {/* Upload Zone */}
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`
            relative border-2 border-dashed rounded-xl p-8 text-center
            transition-all duration-200 cursor-pointer mb-4
            ${isDragging ? "border-primary bg-primary/5 scale-[1.01]" : "border-border hover:border-muted-foreground hover:bg-secondary/20"}
            ${file ? "border-[#22c55e] bg-[#22c55e]/5" : ""}
          `}
          onClick={() => document.getElementById("file-input")?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              document.getElementById("file-input")?.click()
            }
          }}
        >
          <input
            id="file-input"
            type="file"
            accept=".wav"
            onChange={handleFileSelect}
            className="hidden"
          />
          
          {file ? (
            <div className="flex flex-col items-center gap-3">
              <div className="h-14 w-14 rounded-full bg-[#22c55e]/10 flex items-center justify-center">
                <Check className="h-7 w-7 text-[#22c55e]" />
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">{file.name}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Taille: {(file.size / 1024 / 1024).toFixed(2)} Mo
                </p>
              </div>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary" className="font-mono text-xs">4 canaux</Badge>
                <Badge variant="secondary" className="font-mono text-xs">16 kHz</Badge>
                <Badge variant="secondary" className="font-mono text-xs">16-bit PCM</Badge>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div className="h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
                <Upload className="h-7 w-7 text-muted-foreground" />
              </div>
              <div>
                <p className="text-lg font-medium text-foreground">
                  Deposez votre fichier .wav ici
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  ou cliquez pour parcourir (format multicanal requis)
                </p>
              </div>
              <div className="flex gap-2 mt-2">
                <Badge variant="outline" className="font-mono text-xs">.wav</Badge>
                <Badge variant="outline" className="font-mono text-xs">4 canaux</Badge>
                <Badge variant="outline" className="font-mono text-xs">16 kHz</Badge>
              </div>
            </div>
          )}
        </div>

        {/* Loading Progress */}
        {isLoading && (
          <div className="p-4 rounded-xl bg-secondary/30 border border-border mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <span className="text-sm font-medium text-foreground">
                {loadingSteps[loadingStep]}
              </span>
            </div>
            <Progress value={(loadingStep + 1) * 20} className="h-2" />
            <div className="flex justify-between mt-2">
              <span className="text-xs text-muted-foreground">Etape {loadingStep + 1}/5</span>
              <span className="text-xs text-muted-foreground">{(loadingStep + 1) * 20}%</span>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-4">
          <Button
            size="lg"
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12"
            onClick={handleAnalyzeClick}
            disabled={!file || isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Analyse en cours...
              </>
            ) : hasAnalyzed ? (
              <>
                <Play className="mr-2 h-5 w-5" />
                Relancer l&apos;Analyse
              </>
            ) : (
              <>
                <Play className="mr-2 h-5 w-5" />
                Lancer l&apos;Analyse
              </>
            )}
          </Button>

          <span className="text-sm text-muted-foreground">ou</span>

          <Button
            variant="outline"
            size="lg"
            className="flex-1 h-12 border-[#22c55e]/30 text-[#22c55e] hover:bg-[#22c55e]/10"
            onClick={onRunDemo}
            disabled={isLoading}
          >
            <FileAudio className="mr-2 h-5 w-5" />
            Charger Demonstration
          </Button>
        </div>
      </Card>

      {/* Sub-Section: Specifications Techniques */}
      <Card className="p-6 bg-card border-border">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-xl bg-[#f97316]/10 flex items-center justify-center">
            <HardDrive className="h-5 w-5 text-[#f97316]" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-foreground">
              Specifications Techniques
            </h3>
            <p className="text-sm text-muted-foreground">
              Configuration materielle et parametres du systeme
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Dispositif d'Acquisition */}
          <div className="p-4 rounded-xl bg-secondary/30 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <Mic className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">Dispositif</span>
            </div>
            <p className="text-lg font-bold text-foreground">PS Eye</p>
            <p className="text-xs text-muted-foreground">Microphone Array</p>
            <div className="mt-3 pt-3 border-t border-border space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Type</span>
                <span className="text-foreground font-mono">MEMS</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Canaux</span>
                <span className="text-foreground font-mono">4</span>
              </div>
            </div>
          </div>

          {/* Plateforme */}
          <div className="p-4 rounded-xl bg-secondary/30 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <CircuitBoard className="h-4 w-4 text-[#22c55e]" />
              <span className="text-sm font-semibold text-foreground">Plateforme</span>
            </div>
            <p className="text-lg font-bold text-foreground">Raspberry Pi 3B</p>
            <p className="text-xs text-muted-foreground">ARM Cortex-A53</p>
            <div className="mt-3 pt-3 border-t border-border space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">CPU</span>
                <span className="text-foreground font-mono">1.2 GHz</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">RAM</span>
                <span className="text-foreground font-mono">1 Go</span>
              </div>
            </div>
          </div>

          {/* Signal */}
          <div className="p-4 rounded-xl bg-secondary/30 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <Waves className="h-4 w-4 text-[#f97316]" />
              <span className="text-sm font-semibold text-foreground">Signal</span>
            </div>
            <p className="text-lg font-bold text-foreground">16 kHz</p>
            <p className="text-xs text-muted-foreground">Frequence d&apos;echantillonnage</p>
            <div className="mt-3 pt-3 border-t border-border space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Resolution</span>
                <span className="text-foreground font-mono">16-bit</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Format</span>
                <span className="text-foreground font-mono">PCM WAV</span>
              </div>
            </div>
          </div>
        </div>

        {/* Microphone Array Visualization */}
        <div className="mt-6 p-4 rounded-xl bg-secondary/20 border border-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Server className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">Geometrie du Reseau de Microphones</span>
            </div>
            <Badge variant="outline" className="text-xs">Configuration Lineaire</Badge>
          </div>
          
          <div className="flex items-center justify-center gap-8">
            <svg width="240" height="80" viewBox="0 0 240 80" className="shrink-0">
              {/* Background line */}
              <line x1="20" y1="40" x2="220" y2="40" stroke="#2a2b36" strokeWidth="2" />
              <line x1="20" y1="40" x2="220" y2="40" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />
              
              {/* Spacing indicators */}
              <line x1="40" y1="55" x2="90" y2="55" stroke="#6b7280" strokeWidth="1" />
              <line x1="40" y1="52" x2="40" y2="58" stroke="#6b7280" strokeWidth="1" />
              <line x1="90" y1="52" x2="90" y2="58" stroke="#6b7280" strokeWidth="1" />
              <text x="65" y="68" textAnchor="middle" fill="#6b7280" fontSize="9">2 cm</text>
              
              <line x1="90" y1="55" x2="140" y2="55" stroke="#6b7280" strokeWidth="1" />
              <line x1="140" y1="52" x2="140" y2="58" stroke="#6b7280" strokeWidth="1" />
              <text x="115" y="68" textAnchor="middle" fill="#6b7280" fontSize="9">2 cm</text>
              
              <line x1="140" y1="55" x2="190" y2="55" stroke="#6b7280" strokeWidth="1" />
              <line x1="190" y1="52" x2="190" y2="58" stroke="#6b7280" strokeWidth="1" />
              <text x="165" y="68" textAnchor="middle" fill="#6b7280" fontSize="9">2 cm</text>
              
              {/* Microphones - Linear array (4 mics) */}
              <circle cx="40" cy="40" r="12" fill="#3b82f6" opacity="0.9" />
              <text x="40" y="44" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">1</text>
              
              <circle cx="90" cy="40" r="12" fill="#f97316" opacity="0.9" />
              <text x="90" y="44" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">2</text>
              
              <circle cx="140" cy="40" r="12" fill="#22c55e" opacity="0.9" />
              <text x="140" y="44" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">3</text>
              
              <circle cx="190" cy="40" r="12" fill="#ef4444" opacity="0.9" />
              <text x="190" y="44" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">4</text>
              
              {/* Direction indicator */}
              <path d="M115 25 L115 10" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowhead)" opacity="0.6" />
              <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" opacity="0.6" />
                </marker>
              </defs>
            </svg>

            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-[#3b82f6]" />
                <span className="text-xs text-muted-foreground">Canal 1</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-[#f97316]" />
                <span className="text-xs text-muted-foreground">Canal 2</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-[#22c55e]" />
                <span className="text-xs text-muted-foreground">Canal 3</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-[#ef4444]" />
                <span className="text-xs text-muted-foreground">Canal 4</span>
              </div>
              <div className="mt-2 pt-2 border-t border-border">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Espacement</span>
                  <span className="text-foreground font-mono">2 cm</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
