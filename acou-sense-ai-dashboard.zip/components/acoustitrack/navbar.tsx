"use client"

import { Activity, Cpu, Radio, RefreshCw, CheckCircle2, XCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import Image from "next/image"

interface NavbarProps {
  isProcessing: boolean
  modelLoaded?: boolean
  isApiConnected: boolean
  onTestConnection: () => Promise<boolean>
}

export function Navbar({ isProcessing, modelLoaded = true, isApiConnected, onTestConnection }: NavbarProps) {
  const [isTesting, setIsTesting] = useState(false)

  const handleTestConnection = async () => {
    setIsTesting(true)
    await onTestConnection()
    setIsTesting(false)
  }

  return (
    <nav className="w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Left side - Logo & Title */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <Image 
                src="/logo.png" 
                alt="AcoustiTrack Logo" 
                width={48} 
                height={48}
                className="h-12 w-auto"
              />
              {isProcessing && (
                <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-[#22c55e] animate-pulse" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">
                AcoustiTrack
              </h1>
              <p className="text-xs text-muted-foreground font-mono">
                Systeme de Detection et Localisation Acoustique
              </p>
            </div>
          </div>

          {/* Center - Technical Badges */}
          <div className="hidden md:flex items-center gap-2">
            <Badge variant="outline" className="gap-1.5 font-mono text-xs border-border">
              <Radio className="h-3 w-3 text-primary" />
              4 Canaux
            </Badge>
            <Badge variant="outline" className="gap-1.5 font-mono text-xs border-border">
              <Activity className="h-3 w-3 text-[#f97316]" />
              16 kHz
            </Badge>
            <Badge variant="outline" className="gap-1.5 font-mono text-xs border-border">
              <Cpu className="h-3 w-3 text-[#22c55e]" />
              Raspberry Pi 3B
            </Badge>
          </div>

          {/* Right side - Status */}
          <div className="flex items-center gap-4">
            {/* API Colab Status */}
            <Button
              variant="outline"
              size="sm"
              onClick={handleTestConnection}
              disabled={isTesting}
              className={`gap-2 font-mono text-xs ${
                isApiConnected 
                  ? "border-[#22c55e]/50 text-[#22c55e] hover:bg-[#22c55e]/10" 
                  : "border-[#ef4444]/50 text-[#ef4444] hover:bg-[#ef4444]/10"
              }`}
            >
              {isTesting ? (
                <RefreshCw className="h-3 w-3 animate-spin" />
              ) : isApiConnected ? (
                <CheckCircle2 className="h-3 w-3" />
              ) : (
                <XCircle className="h-3 w-3" />
              )}
              {isTesting ? "Test..." : isApiConnected ? "API" : "API"}
            </Button>

            {/* Model Status */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary/50">
              <div
                className={`h-2 w-2 rounded-full ${
                  modelLoaded ? "bg-[#22c55e]" : "bg-[#ef4444]"
                }`}
              />
              <span className="text-xs font-mono text-muted-foreground">
                {modelLoaded ? "CNN-1D" : "Modele non charge"}
              </span>
            </div>

            {/* Live/Idle Status */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary/50">
              <div
                className={`h-2.5 w-2.5 rounded-full ${
                  isProcessing
                    ? "bg-[#22c55e] animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.5)]"
                    : "bg-muted-foreground"
                }`}
              />
              <span
                className={`text-xs font-bold tracking-wider ${
                  isProcessing ? "text-[#22c55e]" : "text-muted-foreground"
                }`}
              >
                {isProcessing ? "EN COURS" : "INACTIF"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
