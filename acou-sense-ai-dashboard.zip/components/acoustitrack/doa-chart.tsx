"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  ReferenceLine,
  Area,
  ComposedChart,
} from "recharts"

interface DOAChartProps {
  doaData: number[]
  isVisible: boolean
}

export function DOAChart({ doaData, isVisible }: DOAChartProps) {
  const [visiblePoints, setVisiblePoints] = useState(0)

  useEffect(() => {
    if (isVisible && doaData.length > 0) {
      setVisiblePoints(0)
      const startTime = Date.now()
      const duration = 2000

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)
        setVisiblePoints(Math.floor(progress * doaData.length))

        if (progress < 1) {
          requestAnimationFrame(animate)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [isVisible, doaData.length])

  if (!isVisible || doaData.length === 0) return null

  const chartData = doaData.slice(0, visiblePoints).map((angle, index) => ({
    frame: index + 1,
    angle: angle * 1.5, // Scale factor for DOA prediction
    uncertainty: 5 + Math.random() * 3, // Simulated uncertainty band
  }))

  // Calculate statistics (with 1.5x scale factor)
  const visibleAngles = doaData.slice(0, visiblePoints).map(a => a * 1.5)
  const meanAngle = visibleAngles.length > 0 
    ? visibleAngles.reduce((sum, v) => sum + v, 0) / visibleAngles.length 
    : 0
  const stdDev = visibleAngles.length > 1
    ? Math.sqrt(visibleAngles.reduce((sum, v) => sum + Math.pow(v - meanAngle, 2), 0) / visibleAngles.length)
    : 0
  const minAngle = visibleAngles.length > 0 ? Math.min(...visibleAngles) : 0
  const maxAngle = visibleAngles.length > 0 ? Math.max(...visibleAngles) : 0

  return (
    <Card className="p-6 bg-card border-border h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-[#ef4444]/10 flex items-center justify-center">
            <TrendingUp className="h-4 w-4 text-[#ef4444]" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Trajectoire DOA
            </h2>
            <p className="text-xs text-muted-foreground">
              Evolution temporelle de l&apos;angle estime
            </p>
          </div>
        </div>
        
      </div>

      <div className="flex-1 min-h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={chartData}
            margin={{ top: 10, right: 20, bottom: 30, left: 20 }}
          >
            <defs>
              <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ef4444" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="frame"
              stroke="#9ca3af"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: "#2a2b36" }}
              label={{
                value: "Trame (n)",
                position: "bottom",
                fill: "#9ca3af",
                fontSize: 10,
                offset: 15,
              }}
            />
            <YAxis
              domain={[-25, 25]}
              ticks={[-25, -20, -15, -10, -5, 0, 5, 10, 15, 20, 25]}
              stroke="#9ca3af"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: "#2a2b36" }}
              tickFormatter={(v) => `${v}°`}
              label={{
                value: "θ (deg)",
                angle: -90,
                position: "insideLeft",
                fill: "#9ca3af",
                fontSize: 10,
              }}
            />
            <ReferenceLine y={0} stroke="#4b5563" strokeDasharray="3 3" />
            <ReferenceLine y={meanAngle} stroke="#3b82f6" strokeDasharray="5 5" strokeWidth={2} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1b23",
                border: "1px solid #2a2b36",
                borderRadius: "8px",
                fontSize: "12px",
              }}
              labelStyle={{ color: "#9ca3af" }}
              formatter={(value: number) => [`θ = ${value.toFixed(1)}°`, "Angle estime"]}
              labelFormatter={(label) => `Trame ${label}`}
            />
            <Area
              type="monotone"
              dataKey="angle"
              stroke="none"
              fill="url(#areaGradient)"
              isAnimationActive={false}
            />
            <Line
              type="monotone"
              dataKey="angle"
              stroke="#ef4444"
              strokeWidth={2}
              dot={{ fill: "#ef4444", strokeWidth: 0, r: 2 }}
              activeDot={{ r: 5, fill: "#ef4444", stroke: "#fff", strokeWidth: 2 }}
              isAnimationActive={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-3 mt-4 pt-4 border-t border-border">
        <div className="text-center p-2 rounded-lg bg-secondary/30">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Moyenne</p>
          <p className="text-sm font-mono font-bold text-[#3b82f6]">{meanAngle.toFixed(1)}°</p>
        </div>
        <div className="text-center p-2 rounded-lg bg-secondary/30">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Ecart-type</p>
          <p className="text-sm font-mono font-bold text-foreground">{stdDev.toFixed(1)}°</p>
        </div>
        <div className="text-center p-2 rounded-lg bg-secondary/30">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Min</p>
          <p className="text-sm font-mono font-bold text-foreground">{minAngle.toFixed(1)}°</p>
        </div>
        <div className="text-center p-2 rounded-lg bg-secondary/30">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Max</p>
          <p className="text-sm font-mono font-bold text-foreground">{maxAngle.toFixed(1)}°</p>
        </div>
      </div>
    </Card>
  )
}
