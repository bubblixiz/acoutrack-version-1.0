"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Clock, 
  Radio, 
  Mic, 
  Compass, 
  Activity, 
  Zap,
  CheckCircle2,
  AlertCircle
} from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface MetricsBarProps {
  durationSec: number
  snrEstimate: number
  vadData: number[]
  doaData: number[]
  isVisible: boolean
}

export function MetricsBar({
  durationSec,
  snrEstimate,
  vadData,
  doaData,
  isVisible,
}: MetricsBarProps) {
  if (!isVisible) return null

  const voiceRatio = vadData.length > 0
    ? (vadData.filter((v) => v === 1).length / vadData.length) * 100
    : 0

  const meanDoa = doaData.length > 0
    ? doaData.reduce((sum, v) => sum + v, 0) / doaData.length
    : 0

  const stdDoa = doaData.length > 1
    ? Math.sqrt(doaData.reduce((sum, v) => sum + Math.pow(v - meanDoa, 2), 0) / doaData.length)
    : 0

  // Determine quality indicators
  const snrQuality = snrEstimate >= 15 ? "excellent" : snrEstimate >= 10 ? "good" : "poor"
  const voiceQuality = voiceRatio >= 40 ? "excellent" : voiceRatio >= 20 ? "good" : "poor"
  const stabilityQuality = stdDoa <= 10 ? "excellent" : stdDoa <= 20 ? "good" : "poor"

  const qualityColors = {
    excellent: "text-[#22c55e]",
    good: "text-[#f97316]",
    poor: "text-[#ef4444]",
  }

  const qualityBg = {
    excellent: "bg-[#22c55e]/10",
    good: "bg-[#f97316]/10",
    poor: "bg-[#ef4444]/10",
  }

  return (
    <Card className="p-6 bg-card border-border">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-[#f97316]/10 flex items-center justify-center">
            <Activity className="h-4 w-4 text-[#f97316]" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Metriques de Performance
            </h2>
            <p className="text-xs text-muted-foreground">
              Resume de l&apos;analyse acoustique
            </p>
          </div>
        </div>
        <Badge className="bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/20 gap-1">
          <CheckCircle2 className="h-3 w-3" />
          Analyse Complete
        </Badge>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Duration */}
        <div className="p-4 rounded-xl bg-secondary/30 border border-border">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Duree</span>
          </div>
          <p className="text-2xl font-mono font-bold text-foreground">
            {durationSec.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">secondes</p>
        </div>

        {/* SNR */}
        <div className={`p-4 rounded-xl border border-border ${qualityBg[snrQuality]}`}>
          <div className="flex items-center gap-2 mb-2">
            <Radio className="h-4 w-4 text-[#f97316]" />
            <span className="text-xs text-muted-foreground">SNR Estime</span>
          </div>
          <p className={`text-2xl font-mono font-bold ${qualityColors[snrQuality]}`}>
            {snrEstimate.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">dB</p>
          <Progress 
            value={Math.min(100, (snrEstimate / 30) * 100)} 
            className="h-1 mt-2"
          />
        </div>

        {/* Voice Ratio */}
        <div className={`p-4 rounded-xl border border-border ${qualityBg[voiceQuality]}`}>
          <div className="flex items-center gap-2 mb-2">
            <Mic className="h-4 w-4 text-[#22c55e]" />
            <span className="text-xs text-muted-foreground">Ratio Voix</span>
          </div>
          <p className={`text-2xl font-mono font-bold ${qualityColors[voiceQuality]}`}>
            {voiceRatio.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">%</p>
          <Progress 
            value={voiceRatio} 
            className="h-1 mt-2"
          />
        </div>

        {/* Mean DOA */}
        <div className="p-4 rounded-xl bg-secondary/30 border border-border">
          <div className="flex items-center gap-2 mb-2">
            <Compass className="h-4 w-4 text-[#ef4444]" />
            <span className="text-xs text-muted-foreground">DOA Moyen</span>
          </div>
          <p className="text-2xl font-mono font-bold text-foreground">
            {meanDoa >= 0 ? "+" : ""}{meanDoa.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">degres</p>
        </div>

        {/* DOA Stability */}
        <div className={`p-4 rounded-xl border border-border ${qualityBg[stabilityQuality]}`}>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="h-4 w-4 text-[#a855f7]" />
            <span className="text-xs text-muted-foreground">Stabilite</span>
          </div>
          <p className={`text-2xl font-mono font-bold ${qualityColors[stabilityQuality]}`}>
            {stdDoa.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground">ecart-type</p>
          <Progress 
            value={Math.max(0, 100 - stdDoa * 3)} 
            className="h-1 mt-2"
          />
        </div>

        {/* Frames Processed */}
        <div className="p-4 rounded-xl bg-secondary/30 border border-border">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Trames</span>
          </div>
          <p className="text-2xl font-mono font-bold text-foreground">
            {vadData.length}
          </p>
          <p className="text-xs text-muted-foreground">traitees</p>
        </div>
      </div>

      {/* Quality Summary */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            {snrQuality === "excellent" ? (
              <CheckCircle2 className="h-4 w-4 text-[#22c55e]" />
            ) : (
              <AlertCircle className="h-4 w-4 text-[#f97316]" />
            )}
            <span className="text-xs text-muted-foreground">
              Qualite Signal: <span className={qualityColors[snrQuality]}>{snrQuality === "excellent" ? "Excellente" : snrQuality === "good" ? "Bonne" : "Faible"}</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            {voiceQuality === "excellent" ? (
              <CheckCircle2 className="h-4 w-4 text-[#22c55e]" />
            ) : (
              <AlertCircle className="h-4 w-4 text-[#f97316]" />
            )}
            <span className="text-xs text-muted-foreground">
              Detection Voix: <span className={qualityColors[voiceQuality]}>{voiceQuality === "excellent" ? "Excellente" : voiceQuality === "good" ? "Bonne" : "Faible"}</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            {stabilityQuality === "excellent" ? (
              <CheckCircle2 className="h-4 w-4 text-[#22c55e]" />
            ) : (
              <AlertCircle className="h-4 w-4 text-[#f97316]" />
            )}
            <span className="text-xs text-muted-foreground">
              Localisation: <span className={qualityColors[stabilityQuality]}>{stabilityQuality === "excellent" ? "Stable" : stabilityQuality === "good" ? "Moderee" : "Instable"}</span>
            </span>
          </div>
        </div>
      </div>
    </Card>
  )
}
