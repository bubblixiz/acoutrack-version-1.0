"use client"

import { useEffect, useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Waves, ZoomIn, ZoomOut } from "lucide-react"
import { Button } from "@/components/ui/button"

interface WaveformVisualizerProps {
  isVisible: boolean
  audioData?: number[][] // 4 channels of audio samples
  duration?: number
  sampleRate?: number
}

const CHANNEL_COLORS = ["#3b82f6", "#f97316", "#22c55e", "#ef4444"]
const CHANNEL_LABELS = ["Canal 1", "Canal 2", "Canal 3", "Canal 4"]

export function WaveformVisualizer({ 
  isVisible, 
  audioData,
  duration = 10,
  sampleRate = 16000
}: WaveformVisualizerProps) {
  const [zoom, setZoom] = useState(1)
  const [animationProgress, setAnimationProgress] = useState(0)

  // Downsample audio data for visualization (max 500 points per channel)
  const displayData = useMemo(() => {
    if (!audioData || audioData.length === 0) {
      // Generate demo data if no real data
      return CHANNEL_COLORS.map((_, channelIndex) => {
        const points = []
        for (let i = 0; i < 300; i++) {
          const t = (i / 300) * duration
          // Simulate voice/silence pattern
          const isVoice = (t > 1 && t < 3) || (t > 4 && t < 6) || (t > 7 && t < 9)
          const amplitude = isVoice 
            ? (Math.sin(t * 20 + channelIndex) * 0.5 + Math.random() * 0.3) 
            : (Math.random() * 0.05 - 0.025)
          points.push({ time: t, value: amplitude })
        }
        return points
      })
    }

    // Real audio data - downsample to 300 points
    const numPoints = 300
    return audioData.slice(0, 4).map((channelData) => {
      const points = []
      const samplesPerPoint = Math.max(1, Math.floor(channelData.length / numPoints))
      
      for (let i = 0; i < numPoints; i++) {
        const startIdx = i * samplesPerPoint
        const endIdx = Math.min(startIdx + samplesPerPoint, channelData.length)
        
        // Get max absolute value in this segment (peak amplitude)
        let maxVal = 0
        let sum = 0
        for (let j = startIdx; j < endIdx; j++) {
          const absVal = Math.abs(channelData[j])
          if (absVal > maxVal) maxVal = absVal
          sum += channelData[j]
        }
        
        // Use signed value based on sum direction
        const value = sum >= 0 ? maxVal : -maxVal
        const time = (startIdx / channelData.length) * duration
        
        points.push({ time, value })
      }
      return points
    })
  }, [audioData, duration])

  // Animation on visibility
  useEffect(() => {
    if (isVisible) {
      setAnimationProgress(0)
      const startTime = Date.now()
      const animDuration = 1200

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / animDuration, 1)
        setAnimationProgress(progress)

        if (progress < 1) {
          requestAnimationFrame(animate)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [isVisible])

  if (!isVisible) return null

  const samples = audioData ? audioData[0]?.length || 0 : sampleRate * duration

  return (
    <Card className="p-6 bg-card border-border">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Waves className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Visualisation Temporelle Multi-Canal
            </h2>
            <p className="text-xs text-muted-foreground">
              {audioData ? "Signal reel acquis" : "Signal simule"} - Amplitude vs Temps
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
            disabled={zoom <= 0.5}
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-xs font-mono text-muted-foreground w-12 text-center">
            {zoom.toFixed(2)}x
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setZoom(Math.min(2, zoom + 0.25))}
            disabled={zoom >= 2}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        {CHANNEL_COLORS.map((color, index) => {
          const channelData = displayData[index] || []
          const visiblePoints = Math.floor(channelData.length * animationProgress)
          const visibleData = channelData.slice(0, visiblePoints)
          
          // Calculate RMS for this channel
          const rms = Math.sqrt(
            visibleData.reduce((sum, p) => sum + p.value * p.value, 0) / Math.max(visibleData.length, 1)
          )

          return (
            <div key={index} className="relative group">
              <div className="flex items-center gap-3">
                <div className="w-28 flex items-center gap-2">
                  <div
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: color }}
                  />
                  <span className="text-xs font-mono text-muted-foreground">
                    {CHANNEL_LABELS[index]}
                  </span>
                </div>
                <div className="flex-1 h-16 bg-[#0f1117] rounded-lg border border-border overflow-hidden relative">
                  {/* Center line */}
                  <div className="absolute top-1/2 left-0 right-0 h-px bg-[#2a2b36]" />
                  
                  {/* Waveform SVG */}
                  <svg 
                    className="w-full h-full" 
                    viewBox={`0 0 ${300 / zoom} 100`} 
                    preserveAspectRatio="none"
                  >
                    {visibleData.length > 1 && (
                      <path
                        d={visibleData
                          .map((point, i) => {
                            const x = (point.time / duration) * (300 / zoom)
                            const y = 50 - point.value * 45
                            return `${i === 0 ? "M" : "L"} ${x} ${y}`
                          })
                          .join(" ")}
                        fill="none"
                        stroke={color}
                        strokeWidth="1.5"
                        vectorEffect="non-scaling-stroke"
                      />
                    )}
                  </svg>
                </div>
                <div className="w-16 text-right">
                  <Badge variant="outline" className="font-mono text-[10px]">
                    {rms.toFixed(3)} Vrms
                  </Badge>
                </div>
              </div>
            </div>
          )
        })}

        {/* X-axis time labels */}
        <div className="flex items-center gap-3">
          <div className="w-28" />
          <div className="flex-1 flex justify-between text-xs font-mono text-muted-foreground px-1">
            {Array.from({ length: 6 }, (_, i) => {
              const t = (i / 5) * duration
              return <span key={i}>{t.toFixed(1)}s</span>
            })}
          </div>
          <div className="w-16" />
        </div>
      </div>

      {/* Signal Stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-border">
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Duree</p>
          <p className="text-sm font-mono font-semibold text-foreground">{duration.toFixed(1)} s</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Freq. Ech.</p>
          <p className="text-sm font-mono font-semibold text-foreground">{(sampleRate / 1000).toFixed(0)} kHz</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Canaux</p>
          <p className="text-sm font-mono font-semibold text-foreground">4</p>
        </div>
      </div>
    </Card>
  )
}
