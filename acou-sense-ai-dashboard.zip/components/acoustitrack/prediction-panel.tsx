"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Brain, 
  CheckCircle2, 
  Mic, 
  MicOff,
  Target,
  Cpu,
  Layers
} from "lucide-react"

interface PredictionPanelProps {
  vadData: number[]
  doaData: number[]
  isVisible: boolean
}

export function PredictionPanel({ vadData, doaData, isVisible }: PredictionPanelProps) {
  if (!isVisible || vadData.length === 0) return null

  const voiceRatio = (vadData.filter((v) => v === 1).length / vadData.length) * 100
  const meanDoa = doaData.reduce((sum, v) => sum + v, 0) / doaData.length
  const isVoiceDetected = voiceRatio > 30

  // Simulated confidence scores
  const vadConfidence = 94.2 + Math.random() * 4
  const doaConfidence = 87.5 + Math.random() * 8

  return (
    <Card className="p-6 bg-card border-border overflow-hidden relative">
      {/* Background glow effect */}
      <div 
        className={`absolute inset-0 opacity-10 ${isVoiceDetected ? "bg-gradient-to-br from-[#22c55e] to-transparent" : "bg-gradient-to-br from-[#ef4444] to-transparent"}`}
      />
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Brain className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">
                Resultats de Prediction CNN-1D
              </h2>
              <p className="text-xs text-muted-foreground">
                Inference sur modele entraine - Accuracy: 96.2%
              </p>
            </div>
          </div>
          <Badge className="bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/20 gap-1">
            <CheckCircle2 className="h-3 w-3" />
            Inference Complete
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* VAD Prediction */}
          <div className="p-6 rounded-xl bg-secondary/30 border border-border">
            <div className="flex items-center gap-3 mb-4">
              <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${isVoiceDetected ? "bg-[#22c55e]/20" : "bg-[#ef4444]/20"}`}>
                {isVoiceDetected ? (
                  <Mic className="h-6 w-6 text-[#22c55e]" />
                ) : (
                  <MicOff className="h-6 w-6 text-[#ef4444]" />
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                  Detection Activite Vocale
                </h3>
                <p className={`text-2xl font-bold ${isVoiceDetected ? "text-[#22c55e]" : "text-[#ef4444]"}`}>
                  {isVoiceDetected ? "VOIX DETECTEE" : "SILENCE / BRUIT"}
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-muted-foreground">Confiance du modele</span>
                  <span className="text-xs font-mono font-bold text-foreground">{vadConfidence.toFixed(1)}%</span>
                </div>
                <Progress value={vadConfidence} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border">
                <div className="text-center p-2 rounded-lg bg-secondary/50">
                  <p className="text-[10px] text-muted-foreground uppercase">Classe Predite</p>
                  <p className={`text-sm font-bold ${isVoiceDetected ? "text-[#22c55e]" : "text-[#ef4444]"}`}>
                    {isVoiceDetected ? "Voice" : "Silence"}
                  </p>
                </div>
                <div className="text-center p-2 rounded-lg bg-secondary/50">
                  <p className="text-[10px] text-muted-foreground uppercase">Ratio Global</p>
                  <p className="text-sm font-bold text-foreground">{voiceRatio.toFixed(1)}%</p>
                </div>
              </div>
            </div>
          </div>

          {/* DOA Prediction */}
          <div className="p-6 rounded-xl bg-secondary/30 border border-border">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                  Direction d&apos;Arrivee (DOA)
                </h3>
                <p className="text-2xl font-bold text-primary">
                  θ = {meanDoa >= 0 ? "+" : ""}{meanDoa.toFixed(1)}°
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-muted-foreground">Confiance localisation</span>
                  <span className="text-xs font-mono font-bold text-foreground">{doaConfidence.toFixed(1)}%</span>
                </div>
                <Progress value={doaConfidence} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border">
                <div className="text-center p-2 rounded-lg bg-secondary/50">
                  <p className="text-[10px] text-muted-foreground uppercase">Position</p>
                  <p className="text-sm font-bold text-foreground">
                    {meanDoa < -15 ? "Gauche" : meanDoa > 15 ? "Droite" : "Centre"}
                  </p>
                </div>
                <div className="text-center p-2 rounded-lg bg-secondary/50">
                  <p className="text-[10px] text-muted-foreground uppercase">Algorithme</p>
                  <p className="text-sm font-bold text-foreground">CNN-1D</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Model Details */}
        <div className="mt-6 pt-4 border-t border-border">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/30">
              <Cpu className="h-4 w-4 text-primary" />
              <div>
                <p className="text-[10px] text-muted-foreground">Architecture</p>
                <p className="text-xs font-mono font-semibold text-foreground">CNN-1D</p>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/30">
              <Layers className="h-4 w-4 text-[#f97316]" />
              <div>
                <p className="text-[10px] text-muted-foreground">Couches</p>
                <p className="text-xs font-mono font-semibold text-foreground">Conv1D + Dense</p>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </Card>
  )
}
