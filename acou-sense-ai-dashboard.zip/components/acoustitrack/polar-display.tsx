"use client"

import { useEffect, useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Target, Play, Pause } from "lucide-react"
import { Button } from "@/components/ui/button"

interface PolarDisplayProps {
  doaData: number[]
  isVisible: boolean
}

export function PolarDisplay({ doaData, isVisible }: PolarDisplayProps) {
  const [currentFrame, setCurrentFrame] = useState(0)
  const [angleHistory, setAngleHistory] = useState<number[]>([])
  const [isPlaying, setIsPlaying] = useState(true)
  const animationRef = useRef<number | null>(null)

  useEffect(() => {
    if (isVisible && doaData.length > 0 && isPlaying) {
      setCurrentFrame(0)
      setAngleHistory([])

      const startTime = Date.now()
      const duration = 4000

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)
        const frame = Math.floor(progress * (doaData.length - 1))

        setCurrentFrame(frame)
        setAngleHistory((prev) => {
          const newHistory = [...prev, doaData[frame]]
          return newHistory.slice(-8)
        })

        if (progress < 1) {
          animationRef.current = requestAnimationFrame(animate)
        } else {
          setIsPlaying(false)
        }
      }

      animationRef.current = requestAnimationFrame(animate)

      return () => {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current)
        }
      }
    }
  }, [isVisible, doaData, isPlaying])

  const handleSliderChange = (value: number[]) => {
    const frame = value[0]
    setCurrentFrame(frame)
    setIsPlaying(false)
    const start = Math.max(0, frame - 7)
    setAngleHistory(doaData.slice(start, frame + 1))
  }

  const togglePlayback = () => {
    if (!isPlaying) {
      setCurrentFrame(0)
      setAngleHistory([])
    }
    setIsPlaying(!isPlaying)
  }

  if (!isVisible || doaData.length === 0) return null

  const currentAngle = doaData[currentFrame] || 0
  const centerX = 160
  const centerY = 150
  const radius = 120

  const angleToCoords = (angle: number, r: number) => {
    const rad = ((angle - 90) * Math.PI) / 180
    return {
      x: centerX + r * Math.cos(rad),
      y: centerY + r * Math.sin(rad),
    }
  }

  const tickAngles = [-60, -45, -30, -15, 0, 15, 30, 45, 60]
  const needleEnd = angleToCoords(currentAngle, radius - 15)

  // Generate arc segments for signal strength visualization
  const arcSegments = tickAngles.slice(0, -1).map((angle, i) => {
    const nextAngle = tickAngles[i + 1]
    const isActive = currentAngle >= angle && currentAngle < nextAngle
    return { start: angle, end: nextAngle, isActive }
  })

  return (
    <Card className="p-6 bg-card border-border h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Target className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Position Source
            </h2>
            <p className="text-xs text-muted-foreground">
              Affichage polaire en temps reel
            </p>
          </div>
        </div>
        <Badge className="bg-primary/10 text-primary border-primary/20 font-mono">
          θ = {currentAngle.toFixed(1)}°
        </Badge>
      </div>

      {/* SVG Semicircle */}
      <div className="flex-1 flex flex-col items-center justify-center min-h-[200px]">
        <svg width="320" height="200" viewBox="0 0 320 200" className="mx-auto">
          {/* Background arcs */}
          {arcSegments.map((seg, i) => {
            const startRad = ((seg.start - 90) * Math.PI) / 180
            const endRad = ((seg.end - 90) * Math.PI) / 180
            const x1 = centerX + radius * Math.cos(startRad)
            const y1 = centerY + radius * Math.sin(startRad)
            const x2 = centerX + radius * Math.cos(endRad)
            const y2 = centerY + radius * Math.sin(endRad)

            return (
              <path
                key={i}
                d={`M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2} Z`}
                fill={seg.isActive ? "rgba(59, 130, 246, 0.15)" : "transparent"}
                stroke="#2a2b36"
                strokeWidth="1"
              />
            )
          })}

          {/* Outer arc */}
          <path
            d={`M ${centerX - radius} ${centerY} A ${radius} ${radius} 0 0 1 ${centerX + radius} ${centerY}`}
            fill="none"
            stroke="#3b82f6"
            strokeWidth="3"
          />

          {/* Inner rings */}
          {[0.75, 0.5, 0.25].map((scale) => (
            <path
              key={scale}
              d={`M ${centerX - radius * scale} ${centerY} A ${radius * scale} ${radius * scale} 0 0 1 ${centerX + radius * scale} ${centerY}`}
              fill="none"
              stroke="#2a2b36"
              strokeWidth="1"
            />
          ))}

          {/* Tick marks and labels */}
          {tickAngles.map((angle) => {
            const innerTick = angleToCoords(angle, radius - 8)
            const outerTick = angleToCoords(angle, radius + 2)
            const labelPos = angleToCoords(angle, radius + 18)

            return (
              <g key={angle}>
                <line
                  x1={innerTick.x}
                  y1={innerTick.y}
                  x2={outerTick.x}
                  y2={outerTick.y}
                  stroke="#4b5563"
                  strokeWidth="2"
                />
                <text
                  x={labelPos.x}
                  y={labelPos.y}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="#9ca3af"
                  fontSize="10"
                  fontFamily="monospace"
                >
                  {angle}°
                </text>
              </g>
            )
          })}

          {/* Ghost trail */}
          {angleHistory.slice(0, -1).map((angle, index) => {
            const opacity = 0.1 + (index / angleHistory.length) * 0.4
            const trailRadius = radius - 20 - (angleHistory.length - index) * 2
            const ghostEnd = angleToCoords(angle, trailRadius)
            return (
              <g key={index}>
                <line
                  x1={centerX}
                  y1={centerY}
                  x2={ghostEnd.x}
                  y2={ghostEnd.y}
                  stroke="#3b82f6"
                  strokeWidth="2"
                  opacity={opacity}
                />
                <circle
                  cx={ghostEnd.x}
                  cy={ghostEnd.y}
                  r="3"
                  fill="#3b82f6"
                  opacity={opacity}
                />
              </g>
            )
          })}

          {/* Main needle */}
          <line
            x1={centerX}
            y1={centerY}
            x2={needleEnd.x}
            y2={needleEnd.y}
            stroke="#3b82f6"
            strokeWidth="4"
            strokeLinecap="round"
            style={{
              transition: "all 0.15s ease-out",
              filter: "drop-shadow(0 0 4px rgba(59, 130, 246, 0.5))",
            }}
          />

          {/* Needle tip */}
          <circle
            cx={needleEnd.x}
            cy={needleEnd.y}
            r="6"
            fill="#3b82f6"
            stroke="#fff"
            strokeWidth="2"
            style={{
              transition: "all 0.15s ease-out",
            }}
          />

          {/* Center dot */}
          <circle cx={centerX} cy={centerY} r="8" fill="#1a1b23" stroke="#3b82f6" strokeWidth="3" />
          <circle cx={centerX} cy={centerY} r="3" fill="#3b82f6" />

          {/* Direction label */}
          <text
            x={centerX}
            y={centerY + 30}
            textAnchor="middle"
            fill="#9ca3af"
            fontSize="9"
            fontFamily="monospace"
          >
            FRONTAL
          </text>
        </svg>

        {/* Current angle display */}
        <div className="text-center mt-2">
          <p className="text-3xl font-bold font-mono text-foreground">
            θ = {currentAngle >= 0 ? "+" : ""}{currentAngle.toFixed(1)}°
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {currentAngle < -15 ? "Source a GAUCHE" : currentAngle > 15 ? "Source a DROITE" : "Source au CENTRE"}
          </p>
        </div>
      </div>

      {/* Playback controls */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={togglePlayback}
            className="w-10 h-10"
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <div className="flex-1">
            <Slider
              value={[currentFrame]}
              min={0}
              max={doaData.length - 1}
              step={1}
              onValueChange={handleSliderChange}
              className="w-full"
            />
          </div>
          <span className="text-xs font-mono text-muted-foreground w-20 text-right">
            {currentFrame + 1} / {doaData.length}
          </span>
        </div>
      </div>
    </Card>
  )
}
