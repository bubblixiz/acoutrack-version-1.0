"use client"

import React, { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AudioWaveform, Mic, MicOff } from "lucide-react"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

interface VADTimelineProps {
  vadData: number[]
  isVisible: boolean
  durationSec: number
  audioData?: number[][] // Optional: real audio data to calculate amplitude-based VAD
}

// Amplitude threshold for voice detection (based on signal amplitude)
const AMPLITUDE_THRESHOLD = 0.02

export function VADTimeline({ vadData, isVisible, durationSec, audioData }: VADTimelineProps) {
  const [visibleSegments, setVisibleSegments] = useState(0)

  // Calculate VAD from audio amplitude if audioData is available
  const computedVadData = React.useMemo(() => {
    if (!audioData || audioData.length === 0 || audioData[0].length === 0) {
      return vadData
    }
    
    // Use first channel for VAD calculation
    const channel = audioData[0]
    const numSegments = vadData.length > 0 ? vadData.length : 20
    const samplesPerSegment = Math.floor(channel.length / numSegments)
    
    const computed: number[] = []
    for (let i = 0; i < numSegments; i++) {
      const start = i * samplesPerSegment
      const end = Math.min(start + samplesPerSegment, channel.length)
      
      // Calculate RMS amplitude for this segment
      let sumSquares = 0
      for (let j = start; j < end; j++) {
        sumSquares += channel[j] * channel[j]
      }
      const rms = Math.sqrt(sumSquares / (end - start))
      
      // Voice if RMS amplitude is above threshold
      computed.push(rms > AMPLITUDE_THRESHOLD ? 1 : 0)
    }
    
    return computed
  }, [audioData, vadData])

  useEffect(() => {
    if (isVisible && computedVadData.length > 0) {
      setVisibleSegments(0)
      const startTime = Date.now()
      const duration = 1500
      const totalSegments = computedVadData.length

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)
        setVisibleSegments(Math.floor(progress * totalSegments))

        if (progress < 1) {
          requestAnimationFrame(animate)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [isVisible, vadData.length])

  if (!isVisible || computedVadData.length === 0) return null

  const timeMarkers = [0, 2, 4, 6, 8, 10].filter((t) => t <= durationSec)
  const voiceCount = computedVadData.filter((v) => v === 1).length
  const silenceCount = computedVadData.length - voiceCount
  const voiceRatio = ((voiceCount / computedVadData.length) * 100).toFixed(1)

  // Calculate voice segments for summary
  const segments: { type: "voice" | "silence"; start: number; end: number }[] = []
  let currentType: "voice" | "silence" | null = null
  let segmentStart = 0

  computedVadData.forEach((v, i) => {
    const type = v === 1 ? "voice" : "silence"
    if (type !== currentType) {
      if (currentType !== null) {
        segments.push({
          type: currentType,
          start: segmentStart,
          end: i,
        })
      }
      currentType = type
      segmentStart = i
    }
  })
  if (currentType !== null) {
    segments.push({
      type: currentType,
      start: segmentStart,
      end: computedVadData.length,
    })
  }

  return (
    <Card className="p-6 bg-card border-border">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-[#22c55e]/10 flex items-center justify-center">
            <AudioWaveform className="h-4 w-4 text-[#22c55e]" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Detection d&apos;Activite Vocale (VAD)
            </h2>
            <p className="text-xs text-muted-foreground">
              Classification binaire par CNN-1D sur trames de 25ms
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/20">
            {voiceRatio}% Voix detectee
          </Badge>
        </div>
      </div>

      {/* Main Timeline */}
      <div className="relative">
        <TooltipProvider>
          <div className="flex gap-[2px] h-12 rounded-lg overflow-hidden bg-secondary/30 p-1">
            {computedVadData.map((value, index) => {
              const isVoice = value === 1
              const isVisibleSegment = index < visibleSegments
              const timeStart = ((index / computedVadData.length) * durationSec).toFixed(2)
              const timeEnd = (((index + 1) / computedVadData.length) * durationSec).toFixed(2)

              return (
                <Tooltip key={index}>
                  <TooltipTrigger asChild>
                    <div
                      className={`
                        flex-1 rounded-sm transition-all duration-150 cursor-pointer
                        hover:scale-y-110 hover:brightness-110
                        ${isVisibleSegment
                          ? isVoice
                            ? "bg-[#22c55e]"
                            : "bg-[#ef4444]/60"
                          : "bg-secondary"
                        }
                      `}
                    />
                  </TooltipTrigger>
                  <TooltipContent className="bg-card border-border">
                    <div className="text-xs space-y-1">
                      <p className="font-semibold">
                        Trame {index + 1} / {computedVadData.length}
                      </p>
                      <p className="text-muted-foreground">
                        {timeStart}s - {timeEnd}s
                      </p>
                      <p className={isVoice ? "text-[#22c55e]" : "text-[#ef4444]"}>
                        {isVoice ? "VOIX DETECTEE" : "SILENCE"}
                      </p>
                    </div>
                  </TooltipContent>
                </Tooltip>
              )
            })}
          </div>
        </TooltipProvider>

        {/* Time markers */}
        <div className="flex justify-between mt-2 px-1">
          {timeMarkers.map((t) => (
            <span key={t} className="text-xs font-mono text-muted-foreground">
              {t}s
            </span>
          ))}
        </div>
      </div>

      {/* Statistics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-4 border-t border-border">
        <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
          <div className="h-10 w-10 rounded-lg bg-[#22c55e]/10 flex items-center justify-center">
            <Mic className="h-5 w-5 text-[#22c55e]" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Trames Voix</p>
            <p className="text-lg font-mono font-bold text-foreground">{voiceCount}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
          <div className="h-10 w-10 rounded-lg bg-[#ef4444]/10 flex items-center justify-center">
            <MicOff className="h-5 w-5 text-[#ef4444]" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Trames Silence</p>
            <p className="text-lg font-mono font-bold text-foreground">{silenceCount}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <span className="text-sm font-bold text-primary">#</span>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Segments Voix</p>
            <p className="text-lg font-mono font-bold text-foreground">
              {segments.filter((s) => s.type === "voice").length}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
          <div className="h-10 w-10 rounded-lg bg-[#f97316]/10 flex items-center justify-center">
            <span className="text-sm font-bold text-[#f97316]">%</span>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Ratio Voix</p>
            <p className="text-lg font-mono font-bold text-foreground">{voiceRatio}%</p>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-8 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-[#22c55e] rounded-sm" />
          <span className="text-sm text-muted-foreground">Voix (Voice)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-[#ef4444]/60 rounded-sm" />
          <span className="text-sm text-muted-foreground">Silence</span>
        </div>
      </div>
    </Card>
  )
}
